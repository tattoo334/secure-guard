// 隐私保护页面
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { privacyService } from '@services/privacyService';
import { PrivacyLeakItem, AppLockState } from '@types/privacy';
import { Card } from '@components/ui/Card';
import { Button } from '@components/ui/Button';
import { SettingSwitch } from '@components/ui/SettingSwitch';
import { formatRelativeTime } from '@utils/format';

const riskColors: Record<string, string> = { low: '#FFC107', medium: '#FF9800', high: '#F44336' };
const riskLabels: Record<string, string> = { low: '低风险', medium: '中风险', high: '高风险' };

export default function PrivacyScreen() {
  const { colors } = useTheme();
  const [leaks, setLeaks] = useState<PrivacyLeakItem[]>([]);
  const [appLock, setAppLock] = useState<AppLockState | null>(null);
  const [detecting, setDetecting] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [leakData, lockData] = await Promise.all([
      privacyService.detectPrivacyLeaks(),
      privacyService.getAppLockState(),
    ]);
    setLeaks(leakData);
    setAppLock(lockData);
  };

  const handleDetect = async () => {
    setDetecting(true);
    const data = await privacyService.detectPrivacyLeaks();
    setLeaks(data);
    setDetecting(false);
  };

  const handleFix = async (id: string) => {
    await privacyService.fixLeak(id);
    setLeaks((prev) => prev.map((l) => (l.id === id ? { ...l, fixed: true } : l)));
    Alert.alert('修复成功', '该隐私问题已修复');
  };

  const toggleAppLock = async (enabled: boolean) => {
    const state = await privacyService.toggleAppLock(enabled);
    setAppLock(state);
  };

  const unresolvedLeaks = leaks.filter((l) => !l.fixed);

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        <Text style={[styles.pageTitle, { color: colors.text }]}>隐私保护</Text>
        <Text style={[styles.pageSubtitle, { color: colors.textSecondary }]}>
          全方位守护您的个人隐私
        </Text>

        {/* 隐私评分概览 */}
        <Card style={styles.overviewCard} padding={20}>
          <View style={styles.overviewRow}>
            <View style={[styles.scoreCircle, { backgroundColor: unresolvedLeaks.length > 0 ? colors.warning + '20' : colors.success + '20' }]}>
              <Text style={[styles.scoreNum, { color: unresolvedLeaks.length > 0 ? colors.warning : colors.success }]}>
                {Math.max(0, 100 - unresolvedLeaks.length * 15)}
              </Text>
            </View>
            <View style={styles.overviewText}>
              <Text style={[styles.overviewTitle, { color: colors.text }]}>
                {unresolvedLeaks.length > 0 ? `${unresolvedLeaks.length} 项隐私风险待处理` : '隐私状态良好'}
              </Text>
              <Text style={[styles.overviewDesc, { color: colors.textSecondary }]}>
                定期检测可有效防止隐私泄露
              </Text>
            </View>
          </View>
          <Button
            title={detecting ? '检测中...' : '立即检测隐私'}
            onPress={handleDetect}
            loading={detecting}
            fullWidth
            style={{ marginTop: 16 }}
            icon={<Ionicons name="search-outline" size={18} color="#FFFFFF" />}
          />
        </Card>

        {/* 应用锁 */}
        <Card style={styles.sectionCard} padding={6}>
          <SettingSwitch
            title="应用锁"
            description="为敏感应用添加图案/PIN锁，防止他人访问"
            value={appLock?.enabled ?? false}
            onValueChange={toggleAppLock}
            icon={<Ionicons name="lock-closed-outline" size={22} color={colors.primary} />}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <TouchableOpacity style={styles.menuRow} activeOpacity={0.7}>
            <View style={[styles.menuIcon, { backgroundColor: colors.info + '15' }]}>
              <Ionicons name="eye-off-outline" size={20} color={colors.info} />
            </View>
            <View style={styles.menuText}>
              <Text style={[styles.menuTitle, { color: colors.text }]}>隐私保险箱</Text>
              <Text style={[styles.menuSubtitle, { color: colors.textSecondary }]}>加密存储敏感照片和文件</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={colors.textSecondary} />
          </TouchableOpacity>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <TouchableOpacity style={styles.menuRow} activeOpacity={0.7}>
            <View style={[styles.menuIcon, { backgroundColor: colors.warning + '15' }]}>
              <Ionicons name="location-outline" size={20} color={colors.warning} />
            </View>
            <View style={styles.menuText}>
              <Text style={[styles.menuTitle, { color: colors.text }]}>虚拟定位</Text>
              <Text style={[styles.menuSubtitle, { color: colors.textSecondary }]}>保护真实位置信息</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={colors.textSecondary} />
          </TouchableOpacity>
        </Card>

        {/* 隐私风险列表 */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>
          隐私检测结果 ({unresolvedLeaks.length} 待处理)
        </Text>
        {leaks.map((leak) => (
          <Card key={leak.id} style={styles.leakCard} padding={14}>
            <View style={styles.leakHeader}>
              <View style={[styles.leakIcon, { backgroundColor: riskColors[leak.riskLevel] + '20' }]}>
                <Ionicons name="alert-triangle-outline" size={20} color={riskColors[leak.riskLevel]} />
              </View>
              <View style={styles.leakInfo}>
                <Text style={[styles.leakTitle, { color: leak.fixed ? colors.textSecondary : colors.text }]}>
                  {leak.title}
                </Text>
                <View style={styles.leakMeta}>
                  <View style={[styles.riskTag, { backgroundColor: riskColors[leak.riskLevel] + '15' }]}>
                    <Text style={{ color: riskColors[leak.riskLevel], fontSize: 10, fontWeight: '700' }}>
                      {riskLabels[leak.riskLevel]}
                    </Text>
                  </View>
                  <Text style={[styles.leakTime, { color: colors.textSecondary }]}>
                    {formatRelativeTime(leak.detectedAt)}
                  </Text>
                </View>
              </View>
              {leak.fixed && (
                <View style={[styles.fixedBadge, { backgroundColor: colors.success + '20' }]}>
                  <Ionicons name="checkmark" size={14} color={colors.success} />
                </View>
              )}
            </View>
            <Text style={[styles.leakDesc, { color: colors.textSecondary }]} numberOfLines={2}>
              {leak.description}
            </Text>
            {!leak.fixed && (
              <Button
                title="立即修复"
                onPress={() => handleFix(leak.id)}
                variant="outline"
                size="sm"
                style={{ marginTop: 10, alignSelf: 'flex-start' }}
              />
            )}
          </Card>
        ))}

        <View style={{ height: 30 }} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 16 },
  pageTitle: { fontSize: 28, fontWeight: '800' },
  pageSubtitle: { fontSize: 14, marginTop: 4, marginBottom: 16 },
  overviewCard: { marginBottom: 16 },
  overviewRow: { flexDirection: 'row', alignItems: 'center' },
  scoreCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  scoreNum: { fontSize: 28, fontWeight: '800' },
  overviewText: { flex: 1 },
  overviewTitle: { fontSize: 16, fontWeight: '600' },
  overviewDesc: { fontSize: 13, marginTop: 4 },
  sectionCard: { marginBottom: 16 },
  divider: { height: 1, marginLeft: 52 },
  menuRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 10,
  },
  menuIcon: {
    width: 38,
    height: 38,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  menuText: { flex: 1 },
  menuTitle: { fontSize: 15, fontWeight: '500' },
  menuSubtitle: { fontSize: 12, marginTop: 2 },
  sectionTitle: { fontSize: 17, fontWeight: '700', marginBottom: 12 },
  leakCard: { marginBottom: 10 },
  leakHeader: { flexDirection: 'row', alignItems: 'flex-start' },
  leakIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  leakInfo: { flex: 1 },
  leakTitle: { fontSize: 15, fontWeight: '600' },
  leakMeta: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  riskTag: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6, marginRight: 8 },
  leakTime: { fontSize: 11 },
  fixedBadge: { padding: 4, borderRadius: 10 },
  leakDesc: { fontSize: 13, marginTop: 8, lineHeight: 18 },
});
