// 骚扰拦截页面
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { blockService } from '@services/blockService';
import { BlockRule, BlockRecord } from '@types/block';
import { Card } from '@components/ui/Card';
import { Button } from '@components/ui/Button';
import { SettingSwitch } from '@components/ui/SettingSwitch';
import { EmptyState } from '@components/ui/EmptyState';
import { formatRelativeTime, formatPhoneMask } from '@utils/format';

const markTypeLabels: Record<string, string> = {
  harassment: '骚扰',
  fraud: '诈骗',
  advertising: '广告',
  express: '快递',
  other: '其他',
};

const markTypeColors: Record<string, string> = {
  harassment: '#F44336',
  fraud: '#B71C1C',
  advertising: '#FF9800',
  express: '#4CAF50',
  other: '#9E9E9E',
};

type TabType = 'records' | 'rules';

export default function InterceptScreen() {
  const { colors } = useTheme();
  const [activeTab, setActiveTab] = useState<TabType>('records');
  const [records, setRecords] = useState<BlockRecord[]>([]);
  const [rules, setRules] = useState<BlockRule[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [recordData, ruleData] = await Promise.all([
      blockService.getRecords(1, 50),
      blockService.getRules(),
    ]);
    setRecords(recordData.records);
    setRules(ruleData);
    setUnreadCount(blockService.getUnreadCount());
    setLoading(false);
  };

  const toggleRule = async (id: string) => {
    const updated = await blockService.toggleRule(id);
    if (updated) {
      setRules((prev) => prev.map((r) => (r.id === id ? updated : r)));
    }
  };

  const deleteRule = (id: string) => {
    Alert.alert('删除规则', '确定要删除该拦截规则吗？', [
      { text: '取消', style: 'cancel' },
      {
        text: '删除',
        style: 'destructive',
        onPress: async () => {
          await blockService.deleteRule(id);
          setRules((prev) => prev.filter((r) => r.id !== id));
        },
      },
    ]);
  };

  const deleteRecord = (id: string) => {
    Alert.alert('删除记录', '确定要删除该拦截记录吗？', [
      { text: '取消', style: 'cancel' },
      {
        text: '删除',
        style: 'destructive',
        onPress: async () => {
          await blockService.deleteRecord(id);
          setRecords((prev) => prev.filter((r) => r.id !== id));
        },
      },
    ]);
  };

  const markAllRead = async () => {
    await blockService.markAllAsRead();
    setRecords((prev) => prev.map((r) => ({ ...r, read: true })));
    setUnreadCount(0);
  };

  const totalBlocked = rules.reduce((sum, r) => sum + r.blockCount, 0);

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        <Text style={[styles.pageTitle, { color: colors.text }]}>骚扰拦截</Text>
        <Text style={[styles.pageSubtitle, { color: colors.textSecondary }]}>
          智能拦截骚扰电话和垃圾短信
        </Text>

        {/* 统计卡片 */}
        <Card style={styles.statsCard} padding={20}>
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.danger }]}>{totalBlocked}</Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>累计拦截</Text>
            </View>
            <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.text }]}>{records.length}</Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>拦截记录</Text>
            </View>
            <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.primary }]}>{rules.filter(r => r.enabled).length}</Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>生效规则</Text>
            </View>
          </View>
        </Card>

        {/* 快捷开关 */}
        <Card style={styles.switchCard} padding={6}>
          <SettingSwitch
            title="拦截骚扰电话"
            description="自动识别并拦截标记为骚扰的号码"
            value={true}
            onValueChange={() => {}}
            icon={<Ionicons name="call-outline" size={22} color={colors.primary} />}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <SettingSwitch
            title="拦截垃圾短信"
            description="智能识别广告、诈骗等垃圾短信"
            value={true}
            onValueChange={() => {}}
            icon={<Ionicons name="chatbubble-outline" size={22} color={colors.success} />}
          />
        </Card>

        {/* Tab 切换 */}
        <View style={[styles.tabBar, { backgroundColor: colors.surface }]}>
          <TouchableOpacity
            style={[styles.tabItem, activeTab === 'records' && { borderBottomColor: colors.primary }]}
            onPress={() => setActiveTab('records')}
          >
            <Text style={[styles.tabText, { color: activeTab === 'records' ? colors.primary : colors.textSecondary }]}>
              拦截记录
            </Text>
            {unreadCount > 0 && (
              <View style={[styles.unreadBadge, { backgroundColor: colors.danger }]}>
                <Text style={styles.unreadText}>{unreadCount}</Text>
              </View>
            )}
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tabItem, activeTab === 'rules' && { borderBottomColor: colors.primary }]}
            onPress={() => setActiveTab('rules')}
          >
            <Text style={[styles.tabText, { color: activeTab === 'rules' ? colors.primary : colors.textSecondary }]}>
              拦截规则
            </Text>
          </TouchableOpacity>
        </View>

        {/* 拦截记录列表 */}
        {activeTab === 'records' && (
          <View>
            {unreadCount > 0 && (
              <TouchableOpacity style={styles.markAllBtn} onPress={markAllRead}>
                <Text style={[styles.markAllText, { color: colors.primary }]}>全部标记已读</Text>
              </TouchableOpacity>
            )}
            {records.length === 0 ? (
              <EmptyState icon="checkmark-done-outline" title="暂无拦截记录" description="所有来电和短信均正常" />
            ) : (
              records.map((record) => (
                <Card key={record.id} style={styles.recordCard} padding={14}>
                  <TouchableOpacity
                    onLongPress={() => deleteRecord(record.id)}
                    activeOpacity={0.7}
                  >
                    <View style={styles.recordHeader}>
                      <View
                        style={[
                          styles.recordIcon,
                          { backgroundColor: record.type === 'phone' ? colors.primary + '15' : colors.success + '15' },
                        ]}
                      >
                        <Ionicons
                          name={record.type === 'phone' ? 'call-outline' : 'chatbubble-outline'}
                          size={20}
                          color={record.type === 'phone' ? colors.primary : colors.success}
                        />
                      </View>
                      <View style={styles.recordInfo}>
                        <View style={styles.recordNameRow}>
                          <Text style={[styles.recordPhone, { color: colors.text }]}>
                            {record.contactName || formatPhoneMask(record.phoneNumber)}
                          </Text>
                          {!record.read && <View style={[styles.unreadDot, { backgroundColor: colors.danger }]} />}
                          {record.markType && (
                            <View style={[styles.markTag, { backgroundColor: markTypeColors[record.markType] + '20' }]}>
                              <Text style={{ color: markTypeColors[record.markType], fontSize: 10, fontWeight: '700' }}>
                                {markTypeLabels[record.markType]}
                              </Text>
                            </View>
                          )}
                        </View>
                        <Text style={[styles.recordReason, { color: colors.textSecondary }]}>
                          {record.reason}
                        </Text>
                      </View>
                      <Text style={[styles.recordTime, { color: colors.textSecondary }]}>
                        {formatRelativeTime(record.blockedAt)}
                      </Text>
                    </View>
                    {record.smsContent && (
                      <Text style={[styles.smsContent, { color: colors.textSecondary }]} numberOfLines={2}>
                        {record.smsContent}
                      </Text>
                    )}
                  </TouchableOpacity>
                </Card>
              ))
            )}
          </View>
        )}

        {/* 拦截规则列表 */}
        {activeTab === 'rules' && (
          <View>
            <Button
              title="添加拦截规则"
              onPress={() => Alert.alert('添加规则', '可添加号码、前缀、关键词等拦截规则')}
              variant="outline"
              fullWidth
              style={{ marginBottom: 12 }}
              icon={<Ionicons name="add-outline" size={18} color={colors.primary} />}
            />
            {rules.map((rule) => (
              <Card key={rule.id} style={styles.ruleCard} padding={14}>
                <View style={styles.ruleRow}>
                  <View style={[styles.ruleIcon, { backgroundColor: colors.danger + '15' }]}>
                    <Ionicons name="ban-outline" size={20} color={colors.danger} />
                  </View>
                  <View style={styles.ruleInfo}>
                    <Text style={[styles.ruleValue, { color: colors.text }]}>{rule.value}</Text>
                    <Text style={[styles.ruleDesc, { color: colors.textSecondary }]}>
                      {rule.description} · 已拦截 {rule.blockCount} 次
                    </Text>
                  </View>
                  <TouchableOpacity
                    style={[styles.ruleSwitch, { backgroundColor: rule.enabled ? colors.primary : colors.surfaceSecondary }]}
                    onPress={() => toggleRule(rule.id)}
                  >
                    <View style={[styles.switchThumb, { left: rule.enabled ? 22 : 2 }]} />
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.deleteBtn} onPress={() => deleteRule(rule.id)}>
                    <Ionicons name="trash-outline" size={18} color={colors.textSecondary} />
                  </TouchableOpacity>
                </View>
              </Card>
            ))}
          </View>
        )}

        <View style={{ height: 30 }} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 16 },
  pageTitle: { fontSize: 28, fontWeight: '800' },
  pageSubtitle: { fontSize: 14, marginTop: 4, marginBottom: 16 },
  statsCard: { marginBottom: 16 },
  statsRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around' },
  statItem: { alignItems: 'center', flex: 1 },
  statValue: { fontSize: 24, fontWeight: '700' },
  statLabel: { fontSize: 12, marginTop: 4 },
  statDivider: { width: 1, height: 36 },
  switchCard: { marginBottom: 16 },
  divider: { height: 1, marginLeft: 52 },
  tabBar: {
    flexDirection: 'row',
    borderRadius: 12,
    marginBottom: 16,
    overflow: 'hidden',
  },
  tabItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabText: { fontSize: 15, fontWeight: '600' },
  unreadBadge: {
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 6,
    paddingHorizontal: 5,
  },
  unreadText: { color: '#FFFFFF', fontSize: 10, fontWeight: '700' },
  markAllBtn: { alignSelf: 'flex-end', padding: 8, marginBottom: 8 },
  markAllText: { fontSize: 13, fontWeight: '500' },
  recordCard: { marginBottom: 10 },
  recordHeader: { flexDirection: 'row', alignItems: 'flex-start' },
  recordIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  recordInfo: { flex: 1 },
  recordNameRow: { flexDirection: 'row', alignItems: 'center' },
  recordPhone: { fontSize: 15, fontWeight: '600' },
  unreadDot: { width: 8, height: 8, borderRadius: 4, marginLeft: 6 },
  markTag: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6, marginLeft: 8 },
  recordReason: { fontSize: 12, marginTop: 4 },
  recordTime: { fontSize: 11 },
  smsContent: { fontSize: 13, marginTop: 8, paddingLeft: 50, lineHeight: 18 },
  ruleCard: { marginBottom: 10 },
  ruleRow: { flexDirection: 'row', alignItems: 'center' },
  ruleIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  ruleInfo: { flex: 1 },
  ruleValue: { fontSize: 15, fontWeight: '600' },
  ruleDesc: { fontSize: 12, marginTop: 2 },
  ruleSwitch: {
    width: 44,
    height: 26,
    borderRadius: 13,
    marginRight: 12,
    position: 'relative',
  },
  switchThumb: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: '#FFFFFF',
    position: 'absolute',
    top: 2,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  deleteBtn: { padding: 6 },
});
