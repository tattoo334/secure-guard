// 根布局
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useTheme } from '@hooks/useTheme';

export default function RootLayout() {
  const { colors } = useTheme();

  return (
    <>
      <StatusBar style="auto" />
      <Stack
        screenOptions={{
          headerStyle: { backgroundColor: colors.background },
          headerTitleStyle: { color: colors.text, fontWeight: '600' },
          headerTintColor: colors.primary,
          contentStyle: { backgroundColor: colors.background },
          headerShadowVisible: false,
        }}
      >
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="scan-result" options={{ title: '扫描结果' }} />
        <Stack.Screen name="app-manager" options={{ title: '应用管理' }} />
        <Stack.Screen name="app-detail" options={{ title: '应用详情' }} />
        <Stack.Screen name="privacy" options={{ title: '隐私保护' }} />
        <Stack.Screen name="intercept" options={{ title: '骚扰拦截' }} />
        <Stack.Screen name="settings" options={{ title: '设置' }} />
        <Stack.Screen name="virus-db" options={{ title: '病毒库更新' }} />
        <Stack.Screen name="scan-history" options={{ title: '扫描历史' }} />
      </Stack>
    </>
  );
}
