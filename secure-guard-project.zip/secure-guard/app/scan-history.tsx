// 扫描历史页面
import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { useScanStore } from '@store/scanStore';
import { Card } from '@components/ui/Card';
import { EmptyState } from '@components/ui/EmptyState';
import { SCAN_TYPE_LABELS } from '@utils/constants';
import { formatDateTime, formatDuration } from '@utils/format';

export default function ScanHistoryScreen() {
  const { colors } = useTheme();
  const { history } = useScanStore();

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        <Text style={[styles.pageTitle, { color: colors.text }]}>扫描历史</Text>
        <Text style={[styles.pageSubtitle, { color: colors.textSecondary }]}>
          查看历史扫描记录和结果
        </Text>

        {history.length === 0 ? (
          <EmptyState
            icon="time-outline"
            title="暂无扫描记录"
            description="进行一次病毒扫描后，记录将显示在这里"
          />
        ) : (
          history.map((item, index) => (
            <Card key={item.id} style={styles.historyCard} padding={16}>
              <View style={styles.historyHeader}>
                <View
                  style={[
                    styles.typeIcon,
                    {
                      backgroundColor:
                        item.threatCount > 0 ? colors.danger + '15' : colors.success + '15',
                    },
                  ]}
                >
                  <Ionicons
                    name={item.threatCount > 0 ? 'alert-triangle-outline' : 'shield-checkmark-outline'}
                    size={24}
                    color={item.threatCount > 0 ? colors.danger : colors.success}
                  />
                </View>
                <View style={styles.historyInfo}>
                  <Text style={[styles.scanType, { color: colors.text }]}>
                    {SCAN_TYPE_LABELS[item.scanType]}
                  </Text>
                  <Text style={[styles.scanTime, { color: colors.textSecondary }]}>
                    {formatDateTime(item.startTime, 'YYYY-MM-DD HH:mm')}
                  </Text>
                </View>
                <View
                  style={[
                    styles.resultBadge,
                    {
                      backgroundColor: item.threatCount > 0 ? colors.danger + '15' : colors.success + '15',
                    },
                  ]}
                >
                  <Text
                    style={{
                      color: item.threatCount > 0 ? colors.danger : colors.success,
                      fontSize: 12,
                      fontWeight: '700',
                    }}
                  >
                    {item.threatCount > 0 ? `${item.threatCount} 威胁` : '安全'}
                  </Text>
                </View>
              </View>

              <View style={styles.detailRow}>
                <View style={styles.detailItem}>
                  <Text style={[styles.detailValue, { color: colors.text }]}>{item.scannedCount}</Text>
                  <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>扫描项</Text>
                </View>
                <View style={styles.detailItem}>
                  <Text style={[styles.detailValue, { color: colors.text }]}>{formatDuration(item.duration)}</Text>
                  <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>耗时</Text>
                </View>
                <View style={styles.detailItem}>
                  <Text style={[styles.detailValue, { color: item.resolved ? colors.success : colors.warning }]}>
                    {item.resolved ? '已处理' : '待处理'}
                  </Text>
                  <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>状态</Text>
                </View>
              </View>
            </Card>
          ))
        )}

        <View style={{ height: 30 }} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 16 },
  pageTitle: { fontSize: 28, fontWeight: '800' },
  pageSubtitle: { fontSize: 14, marginTop: 4, marginBottom: 16 },
  historyCard: { marginBottom: 12 },
  historyHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  typeIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  historyInfo: { flex: 1 },
  scanType: { fontSize: 16, fontWeight: '600' },
  scanTime: { fontSize: 12, marginTop: 4 },
  resultBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingTop: 14,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'transparent',
  },
  detailItem: { alignItems: 'center' },
  detailValue: { fontSize: 15, fontWeight: '600' },
  detailLabel: { fontSize: 11, marginTop: 4 },
});
