// 病毒库更新页面
import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { useSecurityStore } from '@store/securityStore';
import { Card } from '@components/ui/Card';
import { Button } from '@components/ui/Button';
import { formatDateTime } from '@utils/format';

export default function VirusDbScreen() {
  const { colors } = useTheme();
  const { overview, updateVirusDb } = useSecurityStore();
  const [updating, setUpdating] = useState(false);
  const [updateResult, setUpdateResult] = useState<'success' | 'failed' | null>(null);

  const handleUpdate = async () => {
    setUpdating(true);
    setUpdateResult(null);
    const success = await updateVirusDb();
    setUpdating(false);
    setUpdateResult(success ? 'success' : 'failed');
  };

  const currentVersion = overview?.virusDbVersion ?? '2026.10.01';
  const lastUpdate = '2026-10-01T08:00:00Z';

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        {/* 病毒库状态卡片 */}
        <Card style={styles.statusCard} padding={24}>
          <View style={styles.iconContainer}>
            <View style={[styles.dbIcon, { backgroundColor: colors.primary + '15' }]}>
              <Ionicons name="cloud-done-outline" size={48} color={colors.primary} />
            </View>
          </View>
          <Text style={[styles.statusTitle, { color: colors.text }]}>病毒库已是最新</Text>
          <Text style={[styles.statusVersion, { color: colors.primary }]}>
            版本 {currentVersion}
          </Text>
          <Text style={[styles.statusTime, { color: colors.textSecondary }]}>
            上次更新: {formatDateTime(lastUpdate, 'YYYY-MM-DD HH:mm')}
          </Text>

          <Button
            title={updating ? '正在更新...' : '检查更新'}
            onPress={handleUpdate}
            loading={updating}
            size="lg"
            fullWidth
            style={{ marginTop: 24 }}
            icon={<Ionicons name="refresh-outline" size={18} color="#FFFFFF" />}
          />

          {updateResult === 'success' && (
            <View style={[styles.resultBox, { backgroundColor: colors.success + '15' }]}>
              <Ionicons name="checkmark-circle" size={18} color={colors.success} />
              <Text style={[styles.resultText, { color: colors.success }]}>病毒库已更新到最新版本</Text>
            </View>
          )}
          {updateResult === 'failed' && (
            <View style={[styles.resultBox, { backgroundColor: colors.danger + '15' }]}>
              <Ionicons name="close-circle" size={18} color={colors.danger} />
              <Text style={[styles.resultText, { color: colors.danger }]}>更新失败，请检查网络后重试</Text>
            </View>
          )}
        </Card>

        {/* 病毒库信息 */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>病毒库详情</Text>
        <Card style={styles.infoCard} padding={6}>
          <View style={styles.infoRow}>
            <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>当前版本</Text>
            <Text style={[styles.infoValue, { color: colors.text }]}>{currentVersion}</Text>
          </View>
          <View style={[styles.infoDivider, { backgroundColor: colors.border }]} />
          <View style={styles.infoRow}>
            <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>发布日期</Text>
            <Text style={[styles.infoValue, { color: colors.text }]}>2026-10-01</Text>
          </View>
          <View style={[styles.infoDivider, { backgroundColor: colors.border }]} />
          <View style={styles.infoRow}>
            <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>病毒特征数</Text>
            <Text style={[styles.infoValue, { color: colors.text }]}>15,847,230</Text>
          </View>
          <View style={[styles.infoDivider, { backgroundColor: colors.border }]} />
          <View style={styles.infoRow}>
            <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>木马特征数</Text>
            <Text style={[styles.infoValue, { color: colors.text }]}>8,432,156</Text>
          </View>
          <View style={[styles.infoDivider, { backgroundColor: colors.border }]} />
          <View style={styles.infoRow}>
            <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>广告软件特征</Text>
            <Text style={[styles.infoValue, { color: colors.text }]}>3,215,890</Text>
          </View>
          <View style={[styles.infoDivider, { backgroundColor: colors.border }]} />
          <View style={styles.infoRow}>
            <Text style={[styles.infoLabel, { color: colors.textSecondary }]}>钓鱼网站库</Text>
            <Text style={[styles.infoValue, { color: colors.text }]}>1,856,420</Text>
          </View>
        </Card>

        {/* 更新说明 */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>本次更新内容</Text>
        <Card style={styles.changelogCard} padding={16}>
          <View style={styles.changelogItem}>
            <View style={[styles.changelogDot, { backgroundColor: colors.danger }]} />
            <Text style={[styles.changelogText, { color: colors.text }]}>
              新增 12,450 个病毒和木马特征识别
            </Text>
          </View>
          <View style={styles.changelogItem}>
            <View style={[styles.changelogDot, { backgroundColor: colors.warning }]} />
            <Text style={[styles.changelogText, { color: colors.text }]}>
              更新 8,930 个广告软件和间谍软件特征
            </Text>
          </View>
          <View style={styles.changelogItem}>
            <View style={[styles.changelogDot, { backgroundColor: colors.info }]} />
            <Text style={[styles.changelogText, { color: colors.text }]}>
              新增 5,620 个钓鱼网站拦截规则
            </Text>
          </View>
          <View style={styles.changelogItem}>
            <View style={[styles.changelogDot, { backgroundColor: colors.success }]} />
            <Text style={[styles.changelogText, { color: colors.text }]}>
              优化启发式扫描引擎，提升检测准确率 15%
            </Text>
          </View>
        </Card>

        {/* 自动更新设置 */}
        <Card style={styles.autoCard} padding={16}>
          <View style={styles.autoHeader}>
            <Ionicons name="sync-outline" size={22} color={colors.primary} />
            <Text style={[styles.autoTitle, { color: colors.text }]}>自动更新</Text>
          </View>
          <Text style={[styles.autoDesc, { color: colors.textSecondary }]}>
            开启后，应用将在 WiFi 环境下自动检查并更新病毒库，确保您始终拥有最新的安全防护。
          </Text>
        </Card>

        <View style={{ height: 30 }} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 16 },
  statusCard: { marginBottom: 20, alignItems: 'center' },
  iconContainer: { marginBottom: 16 },
  dbIcon: {
    width: 88,
    height: 88,
    borderRadius: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusTitle: { fontSize: 20, fontWeight: '700', marginBottom: 8 },
  statusVersion: { fontSize: 16, fontWeight: '600', marginBottom: 4 },
  statusTime: { fontSize: 13 },
  resultBox: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 10,
    marginTop: 16,
    alignSelf: 'stretch',
  },
  resultText: { fontSize: 13, fontWeight: '500', marginLeft: 8 },
  sectionTitle: { fontSize: 17, fontWeight: '700', marginBottom: 12 },
  infoCard: { marginBottom: 20 },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 14,
  },
  infoLabel: { fontSize: 14 },
  infoValue: { fontSize: 14, fontWeight: '600' },
  infoDivider: { height: 1, marginLeft: 14 },
  changelogCard: { marginBottom: 20 },
  changelogItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  changelogDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginTop: 6,
    marginRight: 10,
  },
  changelogText: { fontSize: 14, flex: 1, lineHeight: 20 },
  autoCard: { marginBottom: 16 },
  autoHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  autoTitle: { fontSize: 16, fontWeight: '600', marginLeft: 10 },
  autoDesc: { fontSize: 13, lineHeight: 20 },
});
