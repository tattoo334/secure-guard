// 应用详情页面
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { appService } from '@services/appService';
import { InstalledApp } from '@types/app';
import { Card } from '@components/ui/Card';
import { Button } from '@components/ui/Button';
import { formatFileSize, formatDateTime } from '@utils/format';

export default function AppDetailScreen() {
  const { packageName } = useLocalSearchParams<{ packageName: string }>();
  const router = useRouter();
  const { colors } = useTheme();
  const [app, setApp] = useState<InstalledApp | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (packageName) {
      appService.getAppDetail(packageName).then((data) => {
        setApp(data);
        setLoading(false);
      });
    }
  }, [packageName]);

  if (!app) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background, flex: 1, alignItems: 'center', justifyContent: 'center' }]}>
        <Text style={{ color: colors.textSecondary }}>加载中...</Text>
      </View>
    );
  }

  const dangerousPermissions = app.permissions.filter((p) => p.riskLevel !== 'normal');

  const handleClearCache = async () => {
    const freed = await appService.clearAppCache(app.packageName);
    Alert.alert('清理完成', `已释放 ${formatFileSize(freed)} 缓存空间`);
  };

  const handleUninstall = () => {
    Alert.alert('确认卸载', `确定要卸载「${app.appName}」吗？`, [
      { text: '取消', style: 'cancel' },
      {
        text: '卸载',
        style: 'destructive',
        onPress: async () => {
          await appService.uninstallApp(app.packageName);
          router.back();
        },
      },
    ]);
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        {/* 应用信息卡片 */}
        <Card style={styles.infoCard} padding={20}>
          <View style={styles.appHeader}>
            <View style={[styles.appIcon, { backgroundColor: app.isRisky ? colors.danger + '20' : colors.primary + '15' }]}>
              <Ionicons
                name={app.isRisky ? 'alert-triangle' : 'apps'}
                size={36}
                color={app.isRisky ? colors.danger : colors.primary}
              />
            </View>
            <View style={styles.appTitleInfo}>
              <Text style={[styles.appName, { color: colors.text }]}>{app.appName}</Text>
              <Text style={[styles.appVersion, { color: colors.textSecondary }]}>
                版本 {app.versionName} ({app.versionCode})
              </Text>
              {app.isRisky && (
                <View style={[styles.riskBadge, { backgroundColor: colors.danger + '20', marginTop: 6 }]}>
                  <Ionicons name="warning" size={12} color={colors.danger} />
                  <Text style={[styles.riskText, { color: colors.danger }]}>风险应用</Text>
                </View>
              )}
            </View>
          </View>

          {app.isRisky && app.riskDescription && (
            <View style={[styles.riskAlert, { backgroundColor: colors.danger + '10' }]}>
              <Ionicons name="alert-circle" size={18} color={colors.danger} />
              <Text style={[styles.riskAlertText, { color: colors.danger }]}>{app.riskDescription}</Text>
            </View>
          )}

          <View style={styles.statsGrid}>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.text }]}>{formatFileSize(app.size)}</Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>应用大小</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.text }]}>{formatFileSize(app.cacheSize)}</Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>缓存</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.text }]}>{formatFileSize(app.dataSize)}</Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>数据</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.text, fontSize: 12 }]}>
                {formatDateTime(app.installTime, 'YYYY-MM-DD')}
              </Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>安装时间</Text>
            </View>
          </View>
        </Card>

        {/* 操作按钮 */}
        <View style={styles.actionRow}>
          <Button
            title="清除缓存"
            onPress={handleClearCache}
            variant="secondary"
            style={{ flex: 1, marginRight: 10 }}
            icon={<Ionicons name="trash-outline" size={16} color={colors.text} />}
          />
          {!app.isSystemApp && (
            <Button
              title="卸载应用"
              onPress={handleUninstall}
              variant="danger"
              style={{ flex: 1 }}
              icon={<Ionicons name="remove-circle-outline" size={16} color="#FFFFFF" />}
            />
          )}
        </View>

        {/* 权限列表 */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>
          应用权限 ({dangerousPermissions.length} 项敏感权限)
        </Text>
        <Card style={styles.permissionCard} padding={6}>
          {app.permissions.length === 0 ? (
            <Text style={[styles.emptyText, { color: colors.textSecondary, padding: 16 }]}>
              该应用未申请任何权限
            </Text>
          ) : (
            app.permissions.map((perm, index) => (
              <View key={perm.name} style={styles.permissionItem}>
                <View
                  style={[
                    styles.permissionIcon,
                    {
                      backgroundColor:
                        perm.riskLevel === 'sensitive'
                          ? colors.danger + '15'
                          : perm.riskLevel === 'dangerous'
                          ? colors.warning + '15'
                          : colors.surfaceSecondary,
                    },
                  ]}
                >
                  <Ionicons
                    name={perm.granted ? 'checkmark' : 'close'}
                    size={16}
                    color={perm.granted ? colors.success : colors.textSecondary}
                  />
                </View>
                <View style={styles.permissionInfo}>
                  <Text style={[styles.permissionName, { color: colors.text }]}>{perm.name}</Text>
                  <Text style={[styles.permissionDesc, { color: colors.textSecondary }]}>
                    {perm.description} · {perm.group}
                  </Text>
                </View>
                <View
                  style={[
                    styles.permissionStatus,
                    {
                      backgroundColor: perm.granted ? colors.success + '15' : colors.surfaceSecondary,
                    },
                  ]}
                >
                  <Text style={{ color: perm.granted ? colors.success : colors.textSecondary, fontSize: 11, fontWeight: '600' }}>
                    {perm.granted ? '已授权' : '未授权'}
                  </Text>
                </View>
                {index < app.permissions.length - 1 && (
                  <View style={[styles.permDivider, { backgroundColor: colors.border }]} />
                )}
              </View>
            ))
          )}
        </Card>

        <View style={{ height: 30 }} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 16 },
  infoCard: { marginBottom: 16 },
  appHeader: { flexDirection: 'row', marginBottom: 16 },
  appIcon: {
    width: 72,
    height: 72,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  appTitleInfo: { flex: 1, justifyContent: 'center' },
  appName: { fontSize: 22, fontWeight: '700' },
  appVersion: { fontSize: 13, marginTop: 4 },
  riskBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  riskText: { fontSize: 11, fontWeight: '700', marginLeft: 4 },
  riskAlert: {
    flexDirection: 'row',
    padding: 12,
    borderRadius: 10,
    marginBottom: 16,
    alignItems: 'flex-start',
  },
  riskAlertText: { fontSize: 13, flex: 1, marginLeft: 8, lineHeight: 18 },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'transparent',
    paddingTop: 16,
  },
  statItem: { width: '25%', alignItems: 'center' },
  statValue: { fontSize: 14, fontWeight: '700' },
  statLabel: { fontSize: 11, marginTop: 4 },
  actionRow: { flexDirection: 'row', marginBottom: 20 },
  sectionTitle: { fontSize: 17, fontWeight: '700', marginBottom: 12 },
  permissionCard: { marginBottom: 16 },
  permissionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 10,
    position: 'relative',
  },
  permissionIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  permissionInfo: { flex: 1 },
  permissionName: { fontSize: 14, fontWeight: '500' },
  permissionDesc: { fontSize: 11, marginTop: 2 },
  permissionStatus: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
  },
  permDivider: {
    position: 'absolute',
    bottom: 0,
    left: 52,
    right: 0,
    height: 1,
  },
  emptyText: { fontSize: 14, textAlign: 'center' },
});
