// 扫描结果页面
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { useScan } from '@hooks/useScan';
import { Card } from '@components/ui/Card';
import { Button } from '@components/ui/Button';
import { ThreatCard } from '@components/features/ThreatCard';
import { EmptyState } from '@components/ui/EmptyState';
import { SCAN_TYPE_LABELS } from '@utils/constants';
import { formatDuration, formatDateTime } from '@utils/format';

export default function ScanResultScreen() {
  const router = useRouter();
  const { colors } = useTheme();
  const { currentResult, resolveThreat, resolveAllThreats, ignoreThreat, clearResult } = useScan();

  if (!currentResult) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <EmptyState
          icon="scan-outline"
          title="暂无扫描结果"
          description="请先进行一次病毒扫描"
          actionLabel="去扫描"
          onAction={() => router.replace('/scan')}
        />
      </View>
    );
  }

  const hasThreats = currentResult.threatCount > 0;
  const unresolvedThreats = currentResult.threats.filter((t) => !t.resolved);

  const handleResolveAll = () => {
    Alert.alert(
      '处理所有威胁',
      `将对 ${unresolvedThreats.length} 个威胁进行处理，包括卸载风险应用和删除恶意文件。是否继续？`,
      [
        { text: '取消', style: 'cancel' },
        {
          text: '立即处理',
          style: 'destructive',
          onPress: () => {
            resolveAllThreats();
            Alert.alert('处理完成', '所有威胁已成功处理');
          },
        },
      ]
    );
  };

  const handleResolveOne = (threatId: string) => {
    resolveThreat(threatId);
  };

  const handleIgnore = (threatId: string) => {
    Alert.alert('忽略威胁', '忽略后该威胁将不再提示，确定要忽略吗？', [
      { text: '取消', style: 'cancel' },
      { text: '忽略', style: 'destructive', onPress: () => ignoreThreat(threatId) },
    ]);
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        {/* 结果概览卡片 */}
        <Card style={styles.summaryCard} padding={20}>
          <View style={styles.summaryHeader}>
            <View
              style={[
                styles.resultIcon,
                { backgroundColor: hasThreats ? colors.danger + '20' : colors.success + '20' },
              ]}
            >
              <Ionicons
                name={hasThreats ? 'alert-circle' : 'checkmark-circle'}
                size={48}
                color={hasThreats ? colors.danger : colors.success}
              />
            </View>
            <View style={styles.summaryText}>
              <Text style={[styles.resultTitle, { color: colors.text }]}>
                {hasThreats ? `发现 ${currentResult.threatCount} 个安全威胁` : '设备安全'}
              </Text>
              <Text style={[styles.resultSubtitle, { color: colors.textSecondary }]}>
                {SCAN_TYPE_LABELS[currentResult.scanType]} · 扫描 {currentResult.scannedCount} 项 ·
                耗时 {formatDuration(currentResult.duration)}
              </Text>
            </View>
          </View>

          <View style={styles.detailRow}>
            <View style={styles.detailItem}>
              <Text style={[styles.detailValue, { color: colors.text }]}>
                {currentResult.scannedCount}
              </Text>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>扫描项</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={[styles.detailValue, { color: colors.danger }]}>
                {currentResult.threatCount}
              </Text>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>威胁</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={[styles.detailValue, { color: colors.text }]}>
                {formatDuration(currentResult.duration)}
              </Text>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>耗时</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={[styles.detailValue, { color: colors.text, fontSize: 11 }]}>
                {currentResult.endTime ? formatDateTime(currentResult.endTime, 'MM-DD HH:mm') : '--'}
              </Text>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>完成时间</Text>
            </View>
          </View>
        </Card>

        {/* 操作按钮 */}
        {hasThreats && unresolvedThreats.length > 0 && (
          <View style={styles.actionRow}>
            <Button
              title="一键处理全部"
              onPress={handleResolveAll}
              variant="danger"
              size="lg"
              style={{ flex: 1, marginRight: 10 }}
              icon={<Ionicons name="shield-checkmark" size={18} color="#FFFFFF" />}
            />
            <Button
              title="重新扫描"
              onPress={() => {
                clearResult();
                router.replace('/scan');
              }}
              variant="outline"
              size="lg"
              style={{ flex: 1 }}
            />
          </View>
        )}

        {!hasThreats && (
          <Button
            title="完成"
            onPress={() => {
              clearResult();
              router.back();
            }}
            size="lg"
            fullWidth
            style={styles.doneBtn}
          />
        )}

        {/* 威胁列表 */}
        {hasThreats && (
          <View style={styles.threatSection}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>
              威胁列表 ({unresolvedThreats.length} 待处理)
            </Text>
            {currentResult.threats.map((threat) => (
              <ThreatCard
                key={threat.id}
                threat={threat}
                onResolve={handleResolveOne}
                onIgnore={handleIgnore}
              />
            ))}
          </View>
        )}

        {/* 安全提示 */}
        {!hasThreats && (
          <Card style={styles.tipCard} padding={16}>
            <View style={styles.tipHeader}>
              <Ionicons name="shield-checkmark-outline" size={20} color={colors.success} />
              <Text style={[styles.tipTitle, { color: colors.text }]}>安全建议</Text>
            </View>
            <Text style={[styles.tipText, { color: colors.textSecondary }]}>
              您的设备当前处于安全状态。建议保持实时防护开启，定期进行全盘扫描，并及时更新病毒库以获得最新的安全防护。
            </Text>
          </Card>
        )}

        <View style={{ height: 30 }} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  summaryCard: {
    marginBottom: 16,
  },
  summaryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  resultIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  summaryText: {
    flex: 1,
  },
  resultTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  resultSubtitle: {
    fontSize: 13,
    lineHeight: 18,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingTop: 16,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'transparent',
  },
  detailItem: {
    alignItems: 'center',
  },
  detailValue: {
    fontSize: 18,
    fontWeight: '700',
  },
  detailLabel: {
    fontSize: 11,
    marginTop: 4,
  },
  actionRow: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  doneBtn: {
    marginBottom: 20,
  },
  threatSection: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 12,
  },
  tipCard: {
    marginBottom: 16,
  },
  tipHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  tipTitle: {
    fontSize: 15,
    fontWeight: '600',
    marginLeft: 8,
  },
  tipText: {
    fontSize: 13,
    lineHeight: 20,
  },
});
