// 扫描页面
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { useScan } from '@hooks/useScan';
import { ScanAnimation } from '@components/ui/ScanAnimation';
import { ScanProgressBar } from '@components/features/ScanProgressBar';
import { Button } from '@components/ui/Button';
import { Card } from '@components/ui/Card';
import { ScanType } from '@types/scan';
import { SCAN_TYPE_LABELS } from '@utils/constants';

export default function ScanScreen() {
  const router = useRouter();
  const { colors } = useTheme();
  const {
    isScanning,
    isPaused,
    currentProgress,
    currentItemName,
    currentResult,
    startScan,
    pauseScan,
    resumeScan,
    cancelScan,
  } = useScan();

  const [selectedType, setSelectedType] = useState<ScanType>('quick');

  const handleStartScan = async (type: ScanType) => {
    setSelectedType(type);
    const result = await startScan(type);
    if (result && result.status === 'completed') {
      router.push('/scan-result');
    }
  };

  const handleCancel = () => {
    Alert.alert('确认取消', '确定要取消当前扫描吗？', [
      { text: '继续扫描', style: 'cancel' },
      {
        text: '取消扫描',
        style: 'destructive',
        onPress: () => cancelScan(),
      },
    ]);
  };

  const scanTypes: Array<{ type: ScanType; icon: string; desc: string }> = [
    { type: 'quick', icon: 'flash-outline', desc: '扫描核心应用和系统关键区域，约30秒' },
    { type: 'full', icon: 'scan-outline', desc: '全面扫描所有应用和文件，约3分钟' },
    { type: 'custom', icon: 'options-outline', desc: '自定义选择扫描范围' },
  ];

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        {/* 标题 */}
        <Text style={[styles.pageTitle, { color: colors.text }]}>病毒扫描</Text>
        <Text style={[styles.pageSubtitle, { color: colors.textSecondary }]}>
          全方位保护您的设备安全
        </Text>

        {/* 扫描动画区域 */}
        <View style={styles.animationContainer}>
          <ScanAnimation size={200} scanning={isScanning} label={isScanning ? '扫描中...' : '准备扫描'} />
        </View>

        {/* 扫描进度 */}
        {isScanning && (
          <Card style={styles.progressCard} padding={16}>
            <ScanProgressBar
              progress={currentProgress}
              currentItem={currentItemName}
              scannedCount={currentResult?.scannedCount}
              totalCount={currentResult?.totalCount}
              threatCount={currentResult?.threatCount}
            />
            <View style={styles.scanActions}>
              {isPaused ? (
                <Button title="继续" onPress={resumeScan} variant="primary" size="sm" style={{ flex: 1, marginRight: 8 }} />
              ) : (
                <Button title="暂停" onPress={pauseScan} variant="secondary" size="sm" style={{ flex: 1, marginRight: 8 }} />
              )}
              <Button title="取消" onPress={handleCancel} variant="outline" size="sm" style={{ flex: 1 }} />
            </View>
          </Card>
        )}

        {/* 扫描类型选择 */}
        {!isScanning && (
          <View style={styles.scanTypes}>
            {scanTypes.map((item) => (
              <TouchableOpacity
                key={item.type}
                style={[
                  styles.scanTypeCard,
                  {
                    backgroundColor: colors.surface,
                    borderColor: selectedType === item.type ? colors.primary : colors.border,
                    borderWidth: selectedType === item.type ? 2 : 1,
                  },
                ]}
                onPress={() => setSelectedType(item.type)}
                activeOpacity={0.7}
              >
                <View style={[styles.typeIcon, { backgroundColor: colors.primary + '15' }]}>
                  <Ionicons name={item.icon as any} size={26} color={colors.primary} />
                </View>
                <Text style={[styles.typeTitle, { color: colors.text }]}>
                  {SCAN_TYPE_LABELS[item.type]}
                </Text>
                <Text style={[styles.typeDesc, { color: colors.textSecondary }]}>{item.desc}</Text>
                {selectedType === item.type && (
                  <View style={[styles.checkBadge, { backgroundColor: colors.primary }]}>
                    <Ionicons name="checkmark" size={14} color="#FFFFFF" />
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* 开始扫描按钮 */}
        {!isScanning && (
          <Button
            title={`开始${SCAN_TYPE_LABELS[selectedType]}`}
            onPress={() => handleStartScan(selectedType)}
            size="lg"
            fullWidth
            style={styles.startBtn}
            icon={<Ionicons name="play" size={18} color="#FFFFFF" />}
          />
        )}

        {/* 扫描提示 */}
        {!isScanning && (
          <Card style={styles.tipCard} padding={14}>
            <View style={styles.tipHeader}>
              <Ionicons name="information-circle-outline" size={18} color={colors.info} />
              <Text style={[styles.tipTitle, { color: colors.text }]}>扫描提示</Text>
            </View>
            <Text style={[styles.tipText, { color: colors.textSecondary }]}>
              扫描过程中请勿关闭应用，扫描引擎会对应用安装包、运行进程和系统文件进行特征码比对。建议在充电状态下进行全盘扫描。
            </Text>
          </Card>
        )}

        <View style={{ height: 30 }} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  pageTitle: {
    fontSize: 28,
    fontWeight: '800',
  },
  pageSubtitle: {
    fontSize: 14,
    marginTop: 4,
    marginBottom: 8,
  },
  animationContainer: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  progressCard: {
    marginBottom: 16,
  },
  scanActions: {
    flexDirection: 'row',
    marginTop: 12,
  },
  scanTypes: {
    gap: 12,
    marginBottom: 20,
  },
  scanTypeCard: {
    borderRadius: 16,
    padding: 16,
    position: 'relative',
    marginBottom: 12,
  },
  typeIcon: {
    width: 52,
    height: 52,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  typeTitle: {
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 4,
  },
  typeDesc: {
    fontSize: 13,
    lineHeight: 18,
  },
  checkBadge: {
    position: 'absolute',
    top: 14,
    right: 14,
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  startBtn: {
    marginBottom: 16,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  tipCard: {
    marginBottom: 16,
  },
  tipHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  tipTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 8,
  },
  tipText: {
    fontSize: 12,
    lineHeight: 18,
  },
});
