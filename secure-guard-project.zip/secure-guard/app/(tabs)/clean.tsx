// 清理加速页面
import React, { useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { useClean } from '@hooks/useClean';
import { Card } from '@components/ui/Card';
import { Button } from '@components/ui/Button';
import { ProgressRing } from '@components/ui/ProgressRing';
import { formatFileSize, formatDuration } from '@utils/format';

export default function CleanScreen() {
  const { colors } = useTheme();
  const {
    junkFiles,
    categories,
    processes,
    memoryInfo,
    batteryInfo,
    loading,
    cleaning,
    selectedJunkSize,
    selectedJunkCount,
    loadAll,
    toggleJunkItem,
    toggleCategory,
    toggleProcess,
    selectAllJunk,
    cleanSelected,
    killSelectedProcesses,
    oneTapBoost,
  } = useClean();

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const handleClean = async () => {
    await cleanSelected();
  };

  const totalJunkSize = junkFiles.reduce((sum, item) => sum + item.size, 0);
  const allSelected = junkFiles.length > 0 && junkFiles.every((item) => item.selected);

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={styles.content}
      refreshControl={
        <RefreshControl refreshing={loading} onRefresh={loadAll} tintColor={colors.primary} />
      }
    >
      {/* 标题 */}
      <Text style={[styles.pageTitle, { color: colors.text }]}>清理加速</Text>
      <Text style={[styles.pageSubtitle, { color: colors.textSecondary }]}>
        释放空间，提升设备性能
      </Text>

      {/* 内存状态卡片 */}
      <Card style={styles.memoryCard} padding={20}>
        <View style={styles.memoryHeader}>
          <ProgressRing
            progress={memoryInfo?.usagePercent ?? 0}
            size={120}
            strokeWidth={10}
            title="内存使用"
            subtitle={memoryInfo ? `${formatFileSize(memoryInfo.usedMemory)} / ${formatFileSize(memoryInfo.totalMemory)}` : ''}
          />
          <View style={styles.memoryStats}>
            <View style={styles.memoryStatItem}>
              <Ionicons name="checkmark-circle-outline" size={18} color={colors.success} />
              <Text style={[styles.memoryStatText, { color: colors.text }]}>
                可用 {memoryInfo ? formatFileSize(memoryInfo.availableMemory) : '--'}
              </Text>
            </View>
            <View style={styles.memoryStatItem}>
              <Ionicons name="apps-outline" size={18} color={colors.primary} />
              <Text style={[styles.memoryStatText, { color: colors.text }]}>
                {processes.filter((p) => !p.isSystemApp).length} 个应用运行中
              </Text>
            </View>
            <View style={styles.memoryStatItem}>
              <Ionicons name="battery-half-outline" size={18} color={colors.warning} />
              <Text style={[styles.memoryStatText, { color: colors.text }]}>
                电量 {batteryInfo?.level ?? '--'}% · 续航约{batteryInfo ? formatDuration(batteryInfo.estimatedRemaining) : '--'}
              </Text>
            </View>
          </View>
        </View>
      </Card>

      {/* 一键加速按钮 */}
      <Button
        title="一键加速"
        onPress={oneTapBoost}
        size="lg"
        fullWidth
        loading={cleaning}
        style={styles.boostBtn}
        icon={<Ionicons name="rocket-outline" size={20} color="#FFFFFF" />}
      />

      {/* 垃圾文件分类 */}
      <View style={styles.sectionHeader}>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>垃圾文件</Text>
        <TouchableOpacity onPress={() => selectAllJunk(!allSelected)}>
          <Text style={[styles.selectAllText, { color: colors.primary }]}>
            {allSelected ? '取消全选' : '全选'}
          </Text>
        </TouchableOpacity>
      </View>

      {categories.map((category) => {
        const categoryAllSelected = category.items.every((item) => item.selected);
        return (
          <Card key={category.type} style={styles.categoryCard} padding={14}>
            <TouchableOpacity
              style={styles.categoryHeader}
              onPress={() => toggleCategory(category.type)}
            >
              <View style={[styles.categoryIcon, { backgroundColor: colors.primary + '15' }]}>
                <Ionicons name={category.icon as any} size={22} color={colors.primary} />
              </View>
              <View style={styles.categoryInfo}>
                <Text style={[styles.categoryName, { color: colors.text }]}>{category.label}</Text>
                <Text style={[styles.categoryMeta, { color: colors.textSecondary }]}>
                  {category.fileCount} 个文件
                </Text>
              </View>
              <View style={styles.categoryRight}>
                <Text style={[styles.categorySize, { color: colors.text }]}>
                  {formatFileSize(category.totalSize)}
                </Text>
                <View style={[styles.checkbox, categoryAllSelected && { backgroundColor: colors.primary, borderColor: colors.primary }]}>
                  {categoryAllSelected && <Ionicons name="checkmark" size={14} color="#FFFFFF" />}
                </View>
              </View>
            </TouchableOpacity>

            {/* 展开的文件列表 */}
            {category.items.map((item) => (
              <TouchableOpacity
                key={item.id}
                style={styles.fileItem}
                onPress={() => toggleJunkItem(item.id)}
              >
                <View style={[styles.fileCheckbox, item.selected && { backgroundColor: colors.primary, borderColor: colors.primary }]}>
                  {item.selected && <Ionicons name="checkmark" size={12} color="#FFFFFF" />}
                </View>
                <View style={styles.fileInfo}>
                  <Text style={[styles.fileName, { color: colors.text }]} numberOfLines={1}>
                    {item.name}
                  </Text>
                  <Text style={[styles.fileMeta, { color: colors.textSecondary }]}>
                    {item.fileCount} 项 · {item.safety === 'caution' ? '建议确认' : '可安全清理'}
                  </Text>
                </View>
                <Text style={[styles.fileSize, { color: colors.textSecondary }]}>
                  {formatFileSize(item.size)}
                </Text>
              </TouchableOpacity>
            ))}
          </Card>
        );
      })}

      {/* 运行中进程 */}
      <Text style={[styles.sectionTitle, { color: colors.text, marginTop: 8 }]}>运行中应用</Text>
      <Card style={styles.processCard} padding={14}>
        {processes.map((process) => (
          <TouchableOpacity
            key={process.id}
            style={styles.processItem}
            onPress={() => !process.isSystemApp && toggleProcess(process.id)}
            disabled={process.isSystemApp}
          >
            <View style={[styles.processCheckbox, process.selected && { backgroundColor: colors.primary, borderColor: colors.primary }, process.isSystemApp && { opacity: 0.3 }]}>
              {process.selected && <Ionicons name="checkmark" size={12} color="#FFFFFF" />}
            </View>
            <View style={styles.processInfo}>
              <Text style={[styles.processName, { color: colors.text }]}>{process.appName}</Text>
              <Text style={[styles.processMeta, { color: colors.textSecondary }]}>
                {formatFileSize(process.memoryUsage)} · CPU {process.cpuUsage}%
                {process.isSystemApp && ' · 系统应用'}
              </Text>
            </View>
          </TouchableOpacity>
        ))}
        <Button
          title="关闭选中应用"
          onPress={killSelectedProcesses}
          variant="outline"
          size="sm"
          style={{ marginTop: 12 }}
          disabled={processes.filter((p) => p.selected).length === 0}
        />
      </Card>

      {/* 底部清理按钮 */}
      <View style={styles.bottomBar}>
        <View style={styles.bottomInfo}>
          <Text style={[styles.bottomLabel, { color: colors.textSecondary }]}>已选</Text>
          <Text style={[styles.bottomSize, { color: colors.text }]}>
            {formatFileSize(selectedJunkSize)}
          </Text>
          <Text style={[styles.bottomCount, { color: colors.textSecondary }]}>
            {selectedJunkCount} 项
          </Text>
        </View>
        <Button
          title="立即清理"
          onPress={handleClean}
          size="lg"
          loading={cleaning}
          disabled={selectedJunkSize === 0}
          style={styles.cleanBtn}
          icon={<Ionicons name="trash-outline" size={18} color="#FFFFFF" />}
        />
      </View>

      <View style={{ height: 100 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  pageTitle: {
    fontSize: 28,
    fontWeight: '800',
  },
  pageSubtitle: {
    fontSize: 14,
    marginTop: 4,
    marginBottom: 16,
  },
  memoryCard: {
    marginBottom: 16,
  },
  memoryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  memoryStats: {
    flex: 1,
    marginLeft: 16,
  },
  memoryStatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  memoryStatText: {
    fontSize: 13,
    marginLeft: 8,
  },
  boostBtn: {
    marginBottom: 20,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 12,
  },
  selectAllText: {
    fontSize: 14,
    fontWeight: '600',
  },
  categoryCard: {
    marginBottom: 12,
  },
  categoryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  categoryIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  categoryInfo: {
    flex: 1,
  },
  categoryName: {
    fontSize: 15,
    fontWeight: '600',
  },
  categoryMeta: {
    fontSize: 12,
    marginTop: 2,
  },
  categoryRight: {
    alignItems: 'flex-end',
  },
  categorySize: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 6,
  },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: '#CCCCCC',
    alignItems: 'center',
    justifyContent: 'center',
  },
  fileItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingLeft: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'transparent',
    marginTop: 4,
  },
  fileCheckbox: {
    width: 18,
    height: 18,
    borderRadius: 9,
    borderWidth: 2,
    borderColor: '#CCCCCC',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  fileInfo: {
    flex: 1,
  },
  fileName: {
    fontSize: 13,
  },
  fileMeta: {
    fontSize: 11,
    marginTop: 2,
  },
  fileSize: {
    fontSize: 13,
    fontWeight: '500',
  },
  processCard: {
    marginBottom: 16,
  },
  processItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
  },
  processCheckbox: {
    width: 18,
    height: 18,
    borderRadius: 9,
    borderWidth: 2,
    borderColor: '#CCCCCC',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  processInfo: {
    flex: 1,
  },
  processName: {
    fontSize: 14,
    fontWeight: '500',
  },
  processMeta: {
    fontSize: 12,
    marginTop: 2,
  },
  bottomBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 4,
  },
  bottomInfo: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  bottomLabel: {
    fontSize: 13,
    marginRight: 6,
  },
  bottomSize: {
    fontSize: 20,
    fontWeight: '700',
    marginRight: 6,
  },
  bottomCount: {
    fontSize: 12,
  },
  cleanBtn: {
    paddingHorizontal: 28,
  },
});
