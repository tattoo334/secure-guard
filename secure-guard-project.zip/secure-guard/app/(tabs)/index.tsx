// 首页 - 安全概览
import React, { useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { useSecurityStore } from '@store/securityStore';
import { useScanStore } from '@store/scanStore';
import { SecurityScoreCard } from '@components/features/SecurityScoreCard';
import { FeatureGrid, FeatureItem } from '@components/features/FeatureGrid';
import { Card } from '@components/ui/Card';
import { formatFileSize } from '@utils/format';

export default function HomeScreen() {
  const router = useRouter();
  const { colors } = useTheme();
  const { overview, loading, fetchOverview, fetchChecks } = useSecurityStore();
  const { isScanning, currentProgress } = useScanStore();

  const loadData = useCallback(async () => {
    await Promise.all([fetchOverview(), fetchChecks()]);
  }, [fetchOverview, fetchChecks]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const featureItems: FeatureItem[] = [
    {
      id: 'virus_scan',
      icon: 'shield-half-outline',
      title: '病毒扫描',
      description: '全面检测',
      color: colors.primary,
      onPress: () => router.push('/scan'),
    },
    {
      id: 'clean',
      icon: 'trash-outline',
      title: '垃圾清理',
      description: overview ? formatFileSize(overview.junkSize) : '扫描中',
      color: colors.success,
      onPress: () => router.push('/clean'),
    },
    {
      id: 'app_manager',
      icon: 'apps-outline',
      title: '应用管理',
      badge: overview?.riskyApps,
      color: colors.warning,
      onPress: () => router.push('/app-manager'),
    },
    {
      id: 'privacy',
      icon: 'lock-closed-outline',
      title: '隐私保护',
      color: colors.info,
      onPress: () => router.push('/privacy'),
    },
    {
      id: 'intercept',
      icon: 'ban-outline',
      title: '骚扰拦截',
      color: colors.danger,
      onPress: () => router.push('/intercept'),
    },
    {
      id: 'virus_db',
      icon: 'cloud-download-outline',
      title: '病毒库',
      description: overview?.virusDbVersion?.slice(0, 7),
      color: colors.primary,
      onPress: () => router.push('/virus-db'),
    },
    {
      id: 'history',
      icon: 'time-outline',
      title: '扫描历史',
      color: colors.textSecondary,
      onPress: () => router.push('/scan-history'),
    },
    {
      id: 'settings',
      icon: 'settings-outline',
      title: '设置',
      color: colors.textSecondary,
      onPress: () => router.push('/settings'),
    },
  ];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={styles.content}
      refreshControl={
        <RefreshControl refreshing={loading} onRefresh={loadData} tintColor={colors.primary} />
      }
    >
      {/* 顶部标题栏 */}
      <View style={styles.header}>
        <View>
          <Text style={[styles.greeting, { color: colors.textSecondary }]}>你好，</Text>
          <Text style={[styles.title, { color: colors.text }]}>安全卫士</Text>
        </View>
        <TouchableOpacity
          style={[styles.headerButton, { backgroundColor: colors.surface }]}
          onPress={() => router.push('/settings')}
        >
          <Ionicons name="settings-outline" size={22} color={colors.text} />
        </TouchableOpacity>
      </View>

      {/* 扫描中状态提示 */}
      {isScanning && (
        <TouchableOpacity
          style={[styles.scanningBanner, { backgroundColor: colors.primary + '15' }]}
          onPress={() => router.push('/scan')}
        >
          <Ionicons name="scan" size={20} color={colors.primary} />
          <Text style={[styles.scanningText, { color: colors.primary }]}>
            正在扫描设备... {currentProgress}%
          </Text>
          <Ionicons name="chevron-forward" size={18} color={colors.primary} />
        </TouchableOpacity>
      )}

      {/* 安全评分卡片 */}
      <SecurityScoreCard overview={overview} />

      {/* 快速扫描按钮 */}
      <TouchableOpacity
        style={[styles.quickScanBtn, { backgroundColor: colors.primary }]}
        onPress={() => router.push('/scan')}
        activeOpacity={0.8}
      >
        <Ionicons name="flash-outline" size={22} color="#FFFFFF" />
        <Text style={styles.quickScanText}>一键安全检测</Text>
        <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
      </TouchableOpacity>

      {/* 功能网格 */}
      <Card style={styles.featureCard} padding={12}>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>安全工具</Text>
        <FeatureGrid items={featureItems} columns={4} />
      </Card>

      {/* 实时防护状态 */}
      <Card style={styles.protectionCard} padding={16}>
        <View style={styles.protectionHeader}>
          <View style={[styles.protectionIcon, { backgroundColor: colors.success + '20' }]}>
            <Ionicons name="eye-outline" size={24} color={colors.success} />
          </View>
          <View style={styles.protectionText}>
            <Text style={[styles.protectionTitle, { color: colors.text }]}>实时防护已开启</Text>
            <Text style={[styles.protectionDesc, { color: colors.textSecondary }]}>
              全天候监控应用安装与文件变化
            </Text>
          </View>
          <View style={[styles.statusDot, { backgroundColor: colors.success }]} />
        </View>
      </Card>

      <View style={{ height: 20 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  greeting: {
    fontSize: 14,
  },
  title: {
    fontSize: 26,
    fontWeight: '800',
    marginTop: 2,
  },
  headerButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scanningBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    marginBottom: 16,
  },
  scanningText: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 10,
  },
  quickScanBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 16,
    marginBottom: 16,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  quickScanText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '700',
    marginHorizontal: 10,
  },
  featureCard: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 8,
    marginLeft: 4,
  },
  protectionCard: {
    marginBottom: 16,
  },
  protectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  protectionIcon: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  protectionText: {
    flex: 1,
  },
  protectionTitle: {
    fontSize: 15,
    fontWeight: '600',
  },
  protectionDesc: {
    fontSize: 12,
    marginTop: 2,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
});
