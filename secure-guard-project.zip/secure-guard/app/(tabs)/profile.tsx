// 个人中心页面
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { useSecurityStore } from '@store/securityStore';
import { useSettingsStore } from '@store/settingsStore';
import { Card } from '@components/ui/Card';
import { SettingSwitch } from '@components/ui/SettingSwitch';

export default function ProfileScreen() {
  const router = useRouter();
  const { colors } = useTheme();
  const { overview, updateVirusDb, setRealtimeProtection } = useSecurityStore();
  const { settings, updateSetting } = useSettingsStore();

  const handleUpdateVirusDb = async () => {
    Alert.alert('更新病毒库', '正在检查最新病毒库版本...');
    const success = await updateVirusDb();
    if (success) {
      Alert.alert('更新成功', '病毒库已更新到最新版本');
    }
  };

  const menuItems = [
    {
      id: 'app_manager',
      icon: 'apps-outline',
      title: '应用管理',
      subtitle: '管理已安装应用和权限',
      color: colors.primary,
      onPress: () => router.push('/app-manager'),
    },
    {
      id: 'privacy',
      icon: 'lock-closed-outline',
      title: '隐私保护',
      subtitle: '应用锁、隐私检测、保险箱',
      color: colors.info,
      onPress: () => router.push('/privacy'),
    },
    {
      id: 'intercept',
      icon: 'ban-outline',
      title: '骚扰拦截',
      subtitle: '电话和短信拦截管理',
      color: colors.danger,
      onPress: () => router.push('/intercept'),
    },
    {
      id: 'virus_db',
      icon: 'cloud-download-outline',
      title: '病毒库更新',
      subtitle: `当前版本 ${overview?.virusDbVersion ?? '--'}`,
      color: colors.success,
      onPress: handleUpdateVirusDb,
    },
    {
      id: 'history',
      icon: 'time-outline',
      title: '扫描历史',
      subtitle: '查看历史扫描记录',
      color: colors.warning,
      onPress: () => router.push('/scan-history'),
    },
    {
      id: 'settings',
      icon: 'settings-outline',
      title: '设置',
      subtitle: '通用设置和偏好',
      color: colors.textSecondary,
      onPress: () => router.push('/settings'),
    },
  ];

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        {/* 用户信息卡片 */}
        <Card style={styles.profileCard} padding={20}>
          <View style={styles.avatarContainer}>
            <View style={[styles.avatar, { backgroundColor: colors.primary }]}>
              <Ionicons name="shield-checkmark" size={40} color="#FFFFFF" />
            </View>
            <View style={styles.userInfo}>
              <Text style={[styles.userName, { color: colors.text }]}>安全卫士用户</Text>
              <Text style={[styles.userLevel, { color: colors.primary }]}>VIP 会员</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.textSecondary} />
          </View>
          <View style={styles.statsDivider} />
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.text }]}>
                {overview?.totalApps ?? 0}
              </Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>已防护应用</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.success }]}>
                {overview?.score ?? 0}
              </Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>安全评分</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.text }]}>365</Text>
              <Text style={[styles.statLabel, { color: colors.textSecondary }]}>已防护天数</Text>
            </View>
          </View>
        </Card>

        {/* 快捷开关 */}
        <Card style={styles.quickSettingsCard} padding={6}>
          <SettingSwitch
            title="实时防护"
            description="全天候监控应用安装和文件变化"
            value={settings.realtimeProtection}
            onValueChange={(v) => {
              updateSetting('realtimeProtection', v);
              setRealtimeProtection(v);
            }}
            icon={<Ionicons name="eye-outline" size={22} color={colors.primary} />}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <SettingSwitch
            title="自动更新病毒库"
            description="在 WiFi 环境下自动更新病毒特征库"
            value={settings.autoUpdateVirusDb}
            onValueChange={(v) => updateSetting('autoUpdateVirusDb', v)}
            icon={<Ionicons name="cloud-outline" size={22} color={colors.success} />}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <SettingSwitch
            title="骚扰短信拦截"
            description="自动识别并拦截垃圾短信"
            value={settings.blockSpamSms}
            onValueChange={(v) => updateSetting('blockSpamSms', v)}
            icon={<Ionicons name="chatbubble-outline" size={22} color={colors.warning} />}
          />
        </Card>

        {/* 功能菜单 */}
        <Card style={styles.menuCard} padding={6}>
          {menuItems.map((item, index) => (
            <TouchableOpacity
              key={item.id}
              style={styles.menuItem}
              onPress={item.onPress}
              activeOpacity={0.7}
            >
              <View style={[styles.menuIcon, { backgroundColor: item.color + '15' }]}>
                <Ionicons name={item.icon as any} size={20} color={item.color} />
              </View>
              <View style={styles.menuText}>
                <Text style={[styles.menuTitle, { color: colors.text }]}>{item.title}</Text>
                {item.subtitle && (
                  <Text style={[styles.menuSubtitle, { color: colors.textSecondary }]}>
                    {item.subtitle}
                  </Text>
                )}
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textSecondary} />
              {index < menuItems.length - 1 && (
                <View style={[styles.menuDivider, { backgroundColor: colors.border }]} />
              )}
            </TouchableOpacity>
          ))}
        </Card>

        {/* 关于 */}
        <Card style={styles.aboutCard} padding={16}>
          <Text style={[styles.aboutTitle, { color: colors.text }]}>关于安全卫士</Text>
          <Text style={[styles.aboutText, { color: colors.textSecondary }]}>
            版本 1.0.0 · 病毒库 {overview?.virusDbVersion ?? '--'}
          </Text>
          <Text style={[styles.aboutText, { color: colors.textSecondary, marginTop: 4 }]}>
            专业的手机安全防护软件，全方位保护您的设备和隐私安全。
          </Text>
        </Card>

        <View style={{ height: 30 }} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  profileCard: {
    marginBottom: 16,
  },
  avatarContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  userInfo: {
    flex: 1,
    marginLeft: 14,
  },
  userName: {
    fontSize: 20,
    fontWeight: '700',
  },
  userLevel: {
    fontSize: 13,
    fontWeight: '600',
    marginTop: 4,
  },
  statsDivider: {
    height: 1,
    backgroundColor: '#F0F0F0',
    marginVertical: 16,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 22,
    fontWeight: '700',
  },
  statLabel: {
    fontSize: 12,
    marginTop: 4,
  },
  quickSettingsCard: {
    marginBottom: 16,
  },
  divider: {
    height: 1,
    marginLeft: 52,
  },
  menuCard: {
    marginBottom: 16,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 10,
    position: 'relative',
  },
  menuIcon: {
    width: 38,
    height: 38,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  menuText: {
    flex: 1,
  },
  menuTitle: {
    fontSize: 15,
    fontWeight: '500',
  },
  menuSubtitle: {
    fontSize: 12,
    marginTop: 2,
  },
  menuDivider: {
    position: 'absolute',
    bottom: 0,
    left: 60,
    right: 0,
    height: 1,
  },
  aboutCard: {
    marginBottom: 16,
  },
  aboutTitle: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 6,
  },
  aboutText: {
    fontSize: 12,
    lineHeight: 18,
  },
});
