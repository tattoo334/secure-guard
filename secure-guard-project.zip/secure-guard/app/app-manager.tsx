// 应用管理页面
import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  FlatList,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { appService } from '@services/appService';
import { InstalledApp } from '@types/app';
import { Card } from '@components/ui/Card';
import { EmptyState } from '@components/ui/EmptyState';
import { formatFileSize, formatRelativeTime } from '@utils/format';

type FilterType = 'all' | 'risky' | 'user' | 'system';

export default function AppManagerScreen() {
  const router = useRouter();
  const { colors } = useTheme();
  const [apps, setApps] = useState<InstalledApp[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchText, setSearchText] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');

  const loadApps = useCallback(async () => {
    setLoading(true);
    const data = await appService.getInstalledApps(true);
    setApps(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadApps();
  }, [loadApps]);

  const filteredApps = apps.filter((app) => {
    if (searchText && !app.appName.toLowerCase().includes(searchText.toLowerCase())) {
      return false;
    }
    switch (filter) {
      case 'risky':
        return app.isRisky;
      case 'user':
        return !app.isSystemApp;
      case 'system':
        return app.isSystemApp;
      default:
        return true;
    }
  });

  const riskyCount = apps.filter((a) => a.isRisky).length;

  const handleUninstall = (app: InstalledApp) => {
    if (app.isSystemApp) {
      Alert.alert('无法卸载', '系统应用无法卸载');
      return;
    }
    Alert.alert('确认卸载', `确定要卸载「${app.appName}」吗？`, [
      { text: '取消', style: 'cancel' },
      {
        text: '卸载',
        style: 'destructive',
        onPress: async () => {
          await appService.uninstallApp(app.packageName);
          setApps((prev) => prev.filter((a) => a.packageName !== app.packageName));
        },
      },
    ]);
  };

  const filters: Array<{ key: FilterType; label: string; count?: number }> = [
    { key: 'all', label: '全部', count: apps.length },
    { key: 'risky', label: '风险', count: riskyCount },
    { key: 'user', label: '用户应用' },
    { key: 'system', label: '系统应用' },
  ];

  const renderAppItem = ({ item }: { item: InstalledApp }) => (
    <TouchableOpacity
      style={[styles.appItem, { backgroundColor: colors.surface }]}
      onPress={() => router.push({ pathname: '/app-detail', params: { packageName: item.packageName } })}
      activeOpacity={0.7}
    >
      <View style={[styles.appIcon, { backgroundColor: item.isRisky ? colors.danger + '20' : colors.primary + '15' }]}>
        <Ionicons
          name={item.isRisky ? 'alert-triangle' : 'apps'}
          size={24}
          color={item.isRisky ? colors.danger : colors.primary}
        />
      </View>
      <View style={styles.appInfo}>
        <View style={styles.appNameRow}>
          <Text style={[styles.appName, { color: colors.text }]} numberOfLines={1}>
            {item.appName}
          </Text>
          {item.isRisky && (
            <View style={[styles.riskBadge, { backgroundColor: colors.danger + '20' }]}>
              <Text style={[styles.riskText, { color: colors.danger }]}>风险</Text>
            </View>
          )}
          {item.isSystemApp && (
            <View style={[styles.systemBadge, { backgroundColor: colors.surfaceSecondary }]}>
              <Text style={[styles.systemText, { color: colors.textSecondary }]}>系统</Text>
            </View>
          )}
        </View>
        <Text style={[styles.appMeta, { color: colors.textSecondary }]}>
          v{item.versionName} · {formatFileSize(item.size)} · {formatRelativeTime(item.lastUpdateTime)}更新
        </Text>
        {item.isRisky && item.riskDescription && (
          <Text style={[styles.riskDesc, { color: colors.danger }]} numberOfLines={1}>
            {item.riskDescription}
          </Text>
        )}
      </View>
      <TouchableOpacity
        style={[styles.uninstallBtn, item.isSystemApp && { opacity: 0.3 }]}
        onPress={() => handleUninstall(item)}
        disabled={item.isSystemApp}
      >
        <Ionicons name="trash-outline" size={18} color={colors.danger} />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* 搜索栏 */}
      <View style={styles.searchContainer}>
        <View style={[styles.searchBox, { backgroundColor: colors.surface }]}>
          <Ionicons name="search-outline" size={18} color={colors.textSecondary} />
          <TextInput
            style={[styles.searchInput, { color: colors.text }]}
            placeholder="搜索应用"
            placeholderTextColor={colors.textPlaceholder}
            value={searchText}
            onChangeText={setSearchText}
          />
          {searchText.length > 0 && (
            <TouchableOpacity onPress={() => setSearchText('')}>
              <Ionicons name="close-circle" size={18} color={colors.textSecondary} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* 筛选标签 */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.filterScroll}
        contentContainerStyle={styles.filterContainer}
      >
        {filters.map((f) => (
          <TouchableOpacity
            key={f.key}
            style={[
              styles.filterTag,
              {
                backgroundColor: filter === f.key ? colors.primary : colors.surface,
                borderColor: filter === f.key ? colors.primary : colors.border,
              },
            ]}
            onPress={() => setFilter(f.key)}
          >
            <Text style={[styles.filterText, { color: filter === f.key ? '#FFFFFF' : colors.text }]}>
              {f.label}
              {f.count !== undefined && ` (${f.count})`}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* 应用列表 */}
      <FlatList
        data={filteredApps}
        keyExtractor={(item) => item.id}
        renderItem={renderAppItem}
        contentContainerStyle={styles.listContent}
        ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
        refreshing={loading}
        onRefresh={loadApps}
        ListEmptyComponent={
          <EmptyState
            icon="apps-outline"
            title="没有找到应用"
            description={searchText ? '尝试其他搜索关键词' : '当前分类下没有应用'}
          />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  searchContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 44,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    marginLeft: 10,
  },
  filterScroll: {
    maxHeight: 44,
  },
  filterContainer: {
    paddingHorizontal: 16,
    paddingBottom: 8,
    gap: 8,
  },
  filterTag: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
  },
  filterText: {
    fontSize: 13,
    fontWeight: '500',
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 20,
  },
  appItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    borderRadius: 14,
  },
  appIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  appInfo: {
    flex: 1,
  },
  appNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  appName: {
    fontSize: 15,
    fontWeight: '600',
    flex: 1,
  },
  riskBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
    marginLeft: 6,
  },
  riskText: {
    fontSize: 10,
    fontWeight: '700',
  },
  systemBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
    marginLeft: 6,
  },
  systemText: {
    fontSize: 10,
  },
  appMeta: {
    fontSize: 12,
    marginTop: 4,
  },
  riskDesc: {
    fontSize: 11,
    marginTop: 4,
  },
  uninstallBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
