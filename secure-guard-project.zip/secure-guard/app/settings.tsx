// 设置页面
import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { useSettingsStore, DarkModeSetting } from '@store/settingsStore';
import { Card } from '@components/ui/Card';
import { SettingSwitch } from '@components/ui/SettingSwitch';

export default function SettingsScreen() {
  const { colors } = useTheme();
  const { settings, updateSetting, resetSettings } = useSettingsStore();

  const darkModeOptions: Array<{ key: DarkModeSetting; label: string; icon: string }> = [
    { key: 'system', label: '跟随系统', icon: 'phone-portrait-outline' },
    { key: 'light', label: '浅色模式', icon: 'sunny-outline' },
    { key: 'dark', label: '深色模式', icon: 'moon-outline' },
  ];

  const handleReset = () => {
    Alert.alert('恢复默认设置', '确定要将所有设置恢复为默认值吗？', [
      { text: '取消', style: 'cancel' },
      { text: '恢复', style: 'destructive', onPress: () => resetSettings() },
    ]);
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        <Text style={[styles.pageTitle, { color: colors.text }]}>设置</Text>

        {/* 扫描设置 */}
        <Text style={[styles.groupTitle, { color: colors.textSecondary }]}>扫描设置</Text>
        <Card style={styles.groupCard} padding={6}>
          <SettingSwitch
            title="实时防护"
            description="监控应用安装和文件变化，实时检测威胁"
            value={settings.realtimeProtection}
            onValueChange={(v) => updateSetting('realtimeProtection', v)}
            icon={<Ionicons name="eye-outline" size={22} color={colors.primary} />}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <SettingSwitch
            title="自动更新病毒库"
            description="在 WiFi 环境下自动更新病毒特征库"
            value={settings.autoUpdateVirusDb}
            onValueChange={(v) => updateSetting('autoUpdateVirusDb', v)}
            icon={<Ionicons name="cloud-download-outline" size={22} color={colors.success} />}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <SettingSwitch
            title="WiFi 自动扫描"
            description="连接 WiFi 时自动进行快速扫描"
            value={settings.autoScanOnWifi}
            onValueChange={(v) => updateSetting('autoScanOnWifi', v)}
            icon={<Ionicons name="wifi-outline" size={22} color={colors.info} />}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <SettingSwitch
            title="扫描 SD 卡"
            description="全盘扫描时包含外部存储设备"
            value={settings.scanSdCard}
            onValueChange={(v) => updateSetting('scanSdCard', v)}
            icon={<Ionicons name="sd-card-outline" size={22} color={colors.warning} />}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <SettingSwitch
            title="隔离威胁文件"
            description="发现威胁时自动隔离，防止进一步传播"
            value={settings.quarantineThreats}
            onValueChange={(v) => updateSetting('quarantineThreats', v)}
            icon={<Ionicons name="lock-closed-outline" size={22} color={colors.danger} />}
          />
        </Card>

        {/* 拦截设置 */}
        <Text style={[styles.groupTitle, { color: colors.textSecondary }]}>拦截设置</Text>
        <Card style={styles.groupCard} padding={6}>
          <SettingSwitch
            title="拦截未知号码"
            description="拦截不在通讯录中的来电"
            value={settings.blockUnknownCalls}
            onValueChange={(v) => updateSetting('blockUnknownCalls', v)}
            icon={<Ionicons name="call-outline" size={22} color={colors.primary} />}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <SettingSwitch
            title="智能拦截垃圾短信"
            description="基于内容识别广告、诈骗等垃圾短信"
            value={settings.blockSpamSms}
            onValueChange={(v) => updateSetting('blockSpamSms', v)}
            icon={<Ionicons name="chatbubble-outline" size={22} color={colors.success} />}
          />
        </Card>

        {/* 通知设置 */}
        <Text style={[styles.groupTitle, { color: colors.textSecondary }]}>通知与显示</Text>
        <Card style={styles.groupCard} padding={6}>
          <SettingSwitch
            title="安全通知"
            description="发现威胁和安全事件时发送通知"
            value={settings.notificationEnabled}
            onValueChange={(v) => updateSetting('notificationEnabled', v)}
            icon={<Ionicons name="notifications-outline" size={22} color={colors.warning} />}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <SettingSwitch
            title="隐藏敏感通知内容"
            description="在锁屏界面隐藏通知详情"
            value={settings.hideSensitiveNotifications}
            onValueChange={(v) => updateSetting('hideSensitiveNotifications', v)}
            icon={<Ionicons name="eye-off-outline" size={22} color={colors.info} />}
          />
        </Card>

        {/* 外观设置 */}
        <Text style={[styles.groupTitle, { color: colors.textSecondary }]}>外观</Text>
        <Card style={styles.groupCard} padding={6}>
          <View style={styles.darkModeRow}>
            <View style={[styles.settingIcon, { backgroundColor: colors.primary + '15' }]}>
              <Ionicons name="color-palette-outline" size={22} color={colors.primary} />
            </View>
            <Text style={[styles.settingTitle, { color: colors.text }]}>深色模式</Text>
            <View style={styles.darkModeOptions}>
              {darkModeOptions.map((option) => (
                <TouchableOpacity
                  key={option.key}
                  style={[
                    styles.darkModeOption,
                    {
                      backgroundColor: settings.darkMode === option.key ? colors.primary : colors.surfaceSecondary,
                    },
                  ]}
                  onPress={() => updateSetting('darkMode', option.key)}
                >
                  <Ionicons
                    name={option.icon as any}
                    size={16}
                    color={settings.darkMode === option.key ? '#FFFFFF' : colors.textSecondary}
                  />
                  <Text
                    style={{
                      color: settings.darkMode === option.key ? '#FFFFFF' : colors.textSecondary,
                      fontSize: 11,
                      marginLeft: 4,
                    }}
                  >
                    {option.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </Card>

        {/* 关于 */}
        <Text style={[styles.groupTitle, { color: colors.textSecondary }]}>关于</Text>
        <Card style={styles.groupCard} padding={6}>
          <TouchableOpacity style={styles.aboutRow} activeOpacity={0.7}>
            <View style={[styles.settingIcon, { backgroundColor: colors.info + '15' }]}>
              <Ionicons name="information-circle-outline" size={22} color={colors.info} />
            </View>
            <Text style={[styles.settingTitle, { color: colors.text }]}>关于安全卫士</Text>
            <Text style={[styles.aboutVersion, { color: colors.textSecondary }]}>v1.0.0</Text>
            <Ionicons name="chevron-forward" size={18} color={colors.textSecondary} />
          </TouchableOpacity>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <TouchableOpacity style={styles.aboutRow} activeOpacity={0.7}>
            <View style={[styles.settingIcon, { backgroundColor: colors.success + '15' }]}>
              <Ionicons name="document-text-outline" size={22} color={colors.success} />
            </View>
            <Text style={[styles.settingTitle, { color: colors.text }]}>隐私政策</Text>
            <Ionicons name="chevron-forward" size={18} color={colors.textSecondary} style={{ marginLeft: 'auto' }} />
          </TouchableOpacity>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <TouchableOpacity style={styles.aboutRow} activeOpacity={0.7}>
            <View style={[styles.settingIcon, { backgroundColor: colors.warning + '15' }]}>
              <Ionicons name="shield-outline" size={22} color={colors.warning} />
            </View>
            <Text style={[styles.settingTitle, { color: colors.text }]}>用户协议</Text>
            <Ionicons name="chevron-forward" size={18} color={colors.textSecondary} style={{ marginLeft: 'auto' }} />
          </TouchableOpacity>
        </Card>

        {/* 恢复默认 */}
        <TouchableOpacity
          style={[styles.resetBtn, { backgroundColor: colors.surface }]}
          onPress={handleReset}
        >
          <Ionicons name="refresh-outline" size={18} color={colors.danger} />
          <Text style={[styles.resetText, { color: colors.danger }]}>恢复默认设置</Text>
        </TouchableOpacity>

        <View style={{ height: 40 }} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 16 },
  pageTitle: { fontSize: 28, fontWeight: '800', marginBottom: 16 },
  groupTitle: { fontSize: 13, fontWeight: '600', marginBottom: 8, marginLeft: 4 },
  groupCard: { marginBottom: 20 },
  divider: { height: 1, marginLeft: 52 },
  settingIcon: {
    width: 38,
    height: 38,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  settingTitle: { fontSize: 15, fontWeight: '500', flex: 1 },
  darkModeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 10,
    flexWrap: 'wrap',
  },
  darkModeOptions: {
    flexDirection: 'row',
    marginLeft: 'auto',
    gap: 6,
  },
  darkModeOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  aboutRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 10,
  },
  aboutVersion: { fontSize: 13, color: '#999', marginRight: 4 },
  resetBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
  },
  resetText: { fontSize: 15, fontWeight: '600', marginLeft: 8 },
});
