// 应用设置 Store
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { DEFAULT_SETTINGS } from '@utils/constants';

export type DarkModeSetting = 'system' | 'light' | 'dark';

export interface AppSettings {
  realtimeProtection: boolean;
  autoUpdateVirusDb: boolean;
  autoScanOnWifi: boolean;
  notificationEnabled: boolean;
  darkMode: DarkModeSetting;
  ignoreSystemApps: boolean;
  quarantineThreats: boolean;
  scanSdCard: boolean;
  scanInstalledApps: boolean;
  scanDownloadFolder: boolean;
  blockUnknownCalls: boolean;
  blockSpamSms: boolean;
  appLockEnabled: boolean;
  hideSensitiveNotifications: boolean;
}

interface SettingsState {
  settings: AppSettings;
  updateSetting: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
  resetSettings: () => void;
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      settings: { ...DEFAULT_SETTINGS },

      updateSetting: (key, value) => {
        set((state) => ({
          settings: { ...state.settings, [key]: value },
        }));
      },

      resetSettings: () => {
        set({ settings: { ...DEFAULT_SETTINGS } });
      },
    }),
    {
      name: 'app-settings-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
