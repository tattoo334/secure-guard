// 扫描状态 Store
import { create } from 'zustand';
import { ScanType, ScanResult, ThreatItem, ScanHistory } from '@types/scan';
import { scanService } from '@services/scanService';
import { storage, StorageKeys } from '@utils/storage';

interface ScanState {
  currentResult: ScanResult | null;
  history: ScanHistory[];
  isScanning: boolean;
  isPaused: boolean;
  currentProgress: number;
  currentItemName: string | null;
  ignoreList: string[];

  startScan: (type: ScanType) => Promise<ScanResult | null>;
  pauseScan: () => void;
  resumeScan: () => void;
  cancelScan: () => void;
  resolveThreat: (threatId: string) => void;
  resolveAllThreats: () => void;
  ignoreThreat: (threatId: string) => void;
  loadHistory: () => Promise<void>;
  clearResult: () => void;
}

const initialResult: ScanResult = {
  scanType: 'quick',
  status: 'idle',
  progress: 0,
  scannedCount: 0,
  totalCount: 0,
  threatCount: 0,
  startTime: null,
  endTime: null,
  duration: 0,
  threats: [],
  currentItem: null,
  scannedItems: [],
};

export const useScanStore = create<ScanState>((set, get) => ({
  currentResult: null,
  history: [],
  isScanning: false,
  isPaused: false,
  currentProgress: 0,
  currentItemName: null,
  ignoreList: [],

  startScan: async (type: ScanType) => {
    if (get().isScanning) return null;

    set({
      isScanning: true,
      isPaused: false,
      currentProgress: 0,
      currentItemName: null,
      currentResult: { ...initialResult, scanType: type, status: 'scanning' },
    });

    try {
      const result = await scanService.startScan(type, (progress, currentItem) => {
        set({
          currentProgress: progress,
          currentItemName: currentItem?.name || null,
          currentResult: {
            ...get().currentResult!,
            progress,
            currentItem,
            scannedCount: get().currentResult?.scannedItems.length || 0,
          },
        });
      });

      // 过滤忽略列表中的威胁
      const filteredThreats = result.threats.filter(
        (t) => !get().ignoreList.includes(t.id)
      );

      const finalResult = {
        ...result,
        threats: filteredThreats,
        threatCount: filteredThreats.length,
      };

      set({
        currentResult: finalResult,
        isScanning: false,
        isPaused: false,
        currentProgress: finalResult.progress,
      });

      // 保存到历史
      if (finalResult.status === 'completed') {
        const historyItem: ScanHistory = {
          id: `${Date.now()}`,
          scanType: type,
          startTime: finalResult.startTime!,
          duration: finalResult.duration,
          scannedCount: finalResult.scannedCount,
          threatCount: finalResult.threatCount,
          resolved: finalResult.threatCount === 0,
        };
        const history = [historyItem, ...get().history].slice(0, 20);
        set({ history });
        storage.set(StorageKeys.SCAN_HISTORY, history);
      }

      return finalResult;
    } catch (error) {
      set({ isScanning: false, isPaused: false });
      return null;
    }
  },

  pauseScan: () => {
    scanService.pause();
    set({ isPaused: true });
  },

  resumeScan: () => {
    scanService.resume();
    set({ isPaused: false });
  },

  cancelScan: () => {
    scanService.cancel();
    set({ isScanning: false, isPaused: false });
  },

  resolveThreat: (threatId: string) => {
    const result = get().currentResult;
    if (!result) return;

    const threats = result.threats.map((t) =>
      t.id === threatId ? { ...t, resolved: true } : t
    );

    set({
      currentResult: {
        ...result,
        threats,
        threatCount: threats.filter((t) => !t.resolved).length,
      },
    });
  },

  resolveAllThreats: () => {
    const result = get().currentResult;
    if (!result) return;

    const threats = result.threats.map((t) => ({ ...t, resolved: true }));
    set({
      currentResult: { ...result, threats, threatCount: 0 },
    });
  },

  ignoreThreat: (threatId: string) => {
    const result = get().currentResult;
    if (!result) return;

    const threats = result.threats.filter((t) => t.id !== threatId);
    const ignoreList = [...get().ignoreList, threatId];

    set({
      currentResult: { ...result, threats, threatCount: threats.length },
      ignoreList,
    });
    storage.set(StorageKeys.THREAT_IGNORE_LIST, ignoreList);
  },

  loadHistory: async () => {
    const history = await storage.get<ScanHistory[]>(StorageKeys.SCAN_HISTORY);
    if (history) set({ history });
  },

  clearResult: () => {
    set({ currentResult: null, currentProgress: 0, currentItemName: null });
  },
}));
