// 清理状态 Store
import { create } from 'zustand';
import {
  JunkFileItem,
  JunkCategory,
  RunningProcess,
  MemoryInfo,
  BatteryInfo,
  CleanResult,
} from '@types/clean';
import { cleanService } from '@services/cleanService';

interface CleanState {
  junkFiles: JunkFileItem[];
  categories: JunkCategory[];
  processes: RunningProcess[];
  memoryInfo: MemoryInfo | null;
  batteryInfo: BatteryInfo | null;
  lastCleanResult: CleanResult | null;
  loading: boolean;
  cleaning: boolean;

  loadJunkFiles: () => Promise<void>;
  loadProcesses: () => Promise<void>;
  loadMemoryInfo: () => Promise<void>;
  loadBatteryInfo: () => Promise<void>;
  loadAll: () => Promise<void>;

  toggleJunkItem: (id: string) => void;
  toggleCategory: (type: string) => void;
  toggleProcess: (id: string) => void;
  selectAllJunk: (selected: boolean) => void;

  cleanSelected: () => Promise<CleanResult | null>;
  killSelectedProcesses: () => Promise<CleanResult | null>;
  oneTapBoost: () => Promise<CleanResult | null>;

  getSelectedJunkSize: () => number;
  getSelectedJunkCount: () => number;
}

export const useCleanStore = create<CleanState>((set, get) => ({
  junkFiles: [],
  categories: [],
  processes: [],
  memoryInfo: null,
  batteryInfo: null,
  lastCleanResult: null,
  loading: false,
  cleaning: false,

  loadJunkFiles: async () => {
    set({ loading: true });
    try {
      const [files, categories] = await Promise.all([
        cleanService.getJunkFiles(),
        cleanService.getJunkCategories(),
      ]);
      set({ junkFiles: files, categories, loading: false });
    } catch {
      set({ loading: false });
    }
  },

  loadProcesses: async () => {
    try {
      const processes = await cleanService.getRunningProcesses();
      set({ processes });
    } catch {
      // 静默失败
    }
  },

  loadMemoryInfo: async () => {
    try {
      const memoryInfo = await cleanService.getMemoryInfo();
      set({ memoryInfo });
    } catch {
      // 静默失败
    }
  },

  loadBatteryInfo: async () => {
    try {
      const batteryInfo = await cleanService.getBatteryInfo();
      set({ batteryInfo });
    } catch {
      // 静默失败
    }
  },

  loadAll: async () => {
    await Promise.all([
      get().loadJunkFiles(),
      get().loadProcesses(),
      get().loadMemoryInfo(),
      get().loadBatteryInfo(),
    ]);
  },

  toggleJunkItem: (id: string) => {
    set({
      junkFiles: get().junkFiles.map((item) =>
        item.id === id ? { ...item, selected: !item.selected } : item
      ),
    });
  },

  toggleCategory: (type: string) => {
    const categoryItems = get().junkFiles.filter((item) => item.type === type);
    const allSelected = categoryItems.every((item) => item.selected);
    set({
      junkFiles: get().junkFiles.map((item) =>
        item.type === type ? { ...item, selected: !allSelected } : item
      ),
    });
  },

  toggleProcess: (id: string) => {
    set({
      processes: get().processes.map((p) =>
        p.id === id ? { ...p, selected: !p.selected } : p
      ),
    });
  },

  selectAllJunk: (selected: boolean) => {
    set({
      junkFiles: get().junkFiles.map((item) => ({ ...item, selected })),
    });
  },

  cleanSelected: async () => {
    set({ cleaning: true });
    try {
      const result = await cleanService.cleanJunkFiles(get().junkFiles);
      // 移除已清理的项目
      set({
        junkFiles: get().junkFiles.filter((item) => !item.selected),
        lastCleanResult: result,
        cleaning: false,
      });
      return result;
    } catch {
      set({ cleaning: false });
      return null;
    }
  },

  killSelectedProcesses: async () => {
    set({ cleaning: true });
    try {
      const result = await cleanService.killProcesses(get().processes);
      set({
        processes: get().processes.filter((p) => !p.selected || p.isSystemApp),
        lastCleanResult: result,
        cleaning: false,
      });
      return result;
    } catch {
      set({ cleaning: false });
      return null;
    }
  },

  oneTapBoost: async () => {
    set({ cleaning: true });
    try {
      const result = await cleanService.oneTapBoost();
      set({ lastCleanResult: result, cleaning: false });
      return result;
    } catch {
      set({ cleaning: false });
      return null;
    }
  },

  getSelectedJunkSize: () => {
    return get()
      .junkFiles.filter((item) => item.selected)
      .reduce((sum, item) => sum + item.size, 0);
  },

  getSelectedJunkCount: () => {
    return get().junkFiles.filter((item) => item.selected).length;
  },
}));
