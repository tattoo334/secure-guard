// 安全状态 Store
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SecurityOverview, SecurityCheckItem, SystemVulnerability } from '@types/security';
import { securityService } from '@services/securityService';

interface SecurityState {
  overview: SecurityOverview | null;
  checks: SecurityCheckItem[];
  vulnerabilities: SystemVulnerability[];
  loading: boolean;
  error: string | null;
  lastUpdated: string | null;

  fetchOverview: () => Promise<void>;
  fetchChecks: () => Promise<void>;
  fetchVulnerabilities: () => Promise<void>;
  refreshAll: () => Promise<void>;
  updateVirusDb: () => Promise<boolean>;
  setRealtimeProtection: (enabled: boolean) => void;
}

export const useSecurityStore = create<SecurityState>()(
  persist(
    (set, get) => ({
      overview: null,
      checks: [],
      vulnerabilities: [],
      loading: false,
      error: null,
      lastUpdated: null,

      fetchOverview: async () => {
        set({ loading: true, error: null });
        try {
          const overview = await securityService.getSecurityOverview();
          set({ overview, loading: false, lastUpdated: new Date().toISOString() });
        } catch (error) {
          set({ error: '获取安全概览失败', loading: false });
        }
      },

      fetchChecks: async () => {
        set({ loading: true, error: null });
        try {
          const checks = await securityService.getSecurityChecks();
          set({ checks, loading: false });
        } catch (error) {
          set({ error: '获取安全检测项失败', loading: false });
        }
      },

      fetchVulnerabilities: async () => {
        set({ loading: true, error: null });
        try {
          const vulnerabilities = await securityService.getSystemVulnerabilities();
          set({ vulnerabilities, loading: false });
        } catch (error) {
          set({ error: '获取系统漏洞失败', loading: false });
        }
      },

      refreshAll: async () => {
        await Promise.all([
          get().fetchOverview(),
          get().fetchChecks(),
          get().fetchVulnerabilities(),
        ]);
      },

      updateVirusDb: async () => {
        try {
          const result = await securityService.updateVirusDatabase();
          if (result.success && get().overview) {
            set({
              overview: { ...get().overview!, virusDbVersion: result.version },
            });
          }
          return result.success;
        } catch {
          return false;
        }
      },

      setRealtimeProtection: (enabled: boolean) => {
        if (get().overview) {
          set({ overview: { ...get().overview!, realtimeProtection: enabled } });
        }
      },
    }),
    {
      name: 'security-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        overview: state.overview,
        lastUpdated: state.lastUpdated,
      }),
    }
  )
);
