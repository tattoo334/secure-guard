// 颜色主题配置

export interface ThemeColors {
  /** 主色调 - 安全蓝 */
  primary: string;
  /** 主色深色 */
  primaryDark: string;
  /** 主色浅色 */
  primaryLight: string;
  /** 成功色 */
  success: string;
  /** 警告色 */
  warning: string;
  /** 危险色 */
  danger: string;
  /** 信息色 */
  info: string;
  /** 页面背景 */
  background: string;
  /** 卡片/表面背景 */
  surface: string;
  /** 次级表面 */
  surfaceSecondary: string;
  /** 主文字 */
  text: string;
  /** 次级文字 */
  textSecondary: string;
  /** 占位文字 */
  textPlaceholder: string;
  /** 边框 */
  border: string;
  /** 分割线 */
  divider: string;
  /** 扫描光晕 */
  scanGlow: string;
  /** 渐变起始 */
  gradientStart: string;
  /** 渐变结束 */
  gradientEnd: string;
  /** 阴影色 */
  shadow: string;
}

export const lightColors: ThemeColors = {
  primary: '#2196F3',
  primaryDark: '#1565C0',
  primaryLight: '#64B5F6',
  success: '#4CAF50',
  warning: '#FF9800',
  danger: '#F44336',
  info: '#00BCD4',
  background: '#F5F7FA',
  surface: '#FFFFFF',
  surfaceSecondary: '#F0F2F5',
  text: '#1A1A2E',
  textSecondary: '#6B7280',
  textPlaceholder: '#9CA3AF',
  border: '#E5E7EB',
  divider: '#F0F0F0',
  scanGlow: 'rgba(33, 150, 243, 0.3)',
  gradientStart: '#2196F3',
  gradientEnd: '#1565C0',
  shadow: 'rgba(0, 0, 0, 0.1)',
};

export const darkColors: ThemeColors = {
  primary: '#42A5F5',
  primaryDark: '#1E88E5',
  primaryLight: '#90CAF9',
  success: '#66BB6A',
  warning: '#FFA726',
  danger: '#EF5350',
  info: '#26C6DA',
  background: '#0A1628',
  surface: '#152238',
  surfaceSecondary: '#1E3050',
  text: '#E8EAF6',
  textSecondary: '#90A4AE',
  textPlaceholder: '#607D8B',
  border: '#2A3F5F',
  divider: '#1E3050',
  scanGlow: 'rgba(66, 165, 245, 0.4)',
  gradientStart: '#1565C0',
  gradientEnd: '#0D47A1',
  shadow: 'rgba(0, 0, 0, 0.4)',
};

export type ThemeMode = 'light' | 'dark';

export function getColors(mode: ThemeMode): ThemeColors {
  return mode === 'dark' ? darkColors : lightColors;
}
