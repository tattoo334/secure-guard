// 排版配置

export const typography = {
  fontFamily: {
    regular: 'System',
    medium: 'System',
    bold: 'System',
  },
  fontSize: {
    /** 超大标题 */
    hero: 48,
    /** 大标题 */
    h1: 32,
    /** 标题 */
    h2: 24,
    /** 小标题 */
    h3: 20,
    /** 正文大 */
    bodyLarge: 18,
    /** 正文 */
    body: 16,
    /** 正文小 */
    bodySmall: 14,
    /** 辅助文字 */
    caption: 12,
    /** 极小文字 */
    tiny: 10,
  },
  fontWeight: {
    regular: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
    extrabold: '800' as const,
  },
  lineHeight: {
    tight: 1.2,
    normal: 1.5,
    relaxed: 1.75,
  },
};

export type Typography = typeof typography;
