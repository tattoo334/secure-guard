// 间距与尺寸配置

export const spacing = {
  /** 2px */
  xs: 2,
  /** 4px */
  sm: 4,
  /** 8px */
  md: 8,
  /** 12px */
  lg: 12,
  /** 16px */
  xl: 16,
  /** 20px */
  xxl: 20,
  /** 24px */
  xxxl: 24,
  /** 32px */
  huge: 32,
  /** 48px */
  massive: 48,
};

export const radius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  xxl: 24,
  full: 9999,
};

export const dimensions = {
  tabBarHeight: 64,
  headerHeight: 56,
  buttonHeight: 48,
  inputHeight: 48,
  cardPadding: 16,
  screenPadding: 20,
  iconSize: {
    sm: 16,
    md: 24,
    lg: 32,
    xl: 48,
    xxl: 64,
  },
};

export type Spacing = typeof spacing;
export type Radius = typeof radius;
export type Dimensions = typeof dimensions;
