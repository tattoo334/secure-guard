// 扫描动画组件 - 雷达扫描效果
import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, Easing } from 'react-native';
import Svg, { Circle, Defs, LinearGradient, Stop, Path } from 'react-native-svg';
import { useTheme } from '@hooks/useTheme';

interface ScanAnimationProps {
  size?: number;
  scanning?: boolean;
  label?: string;
}

export const ScanAnimation: React.FC<ScanAnimationProps> = ({
  size = 200,
  scanning = true,
  label,
}) => {
  const { colors } = useTheme();
  const rotateAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (scanning) {
      // 旋转动画
      const rotate = Animated.loop(
        Animated.timing(rotateAnim, {
          toValue: 1,
          duration: 2000,
          easing: Easing.linear,
          useNativeDriver: true,
        })
      );
      rotate.start();

      // 脉冲动画
      const pulse = Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.1,
            duration: 1000,
            easing: Easing.inOut(Easing.ease),
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 1000,
            easing: Easing.inOut(Easing.ease),
            useNativeDriver: true,
          }),
        ])
      );
      pulse.start();

      return () => {
        rotate.stop();
        pulse.stop();
      };
    }
  }, [scanning, rotateAnim, pulseAnim]);

  const spin = rotateAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  const center = size / 2;
  const radius = size / 2 - 10;

  // 扫描扇形路径
  const sweepPath = `M ${center} ${center} L ${center} ${center - radius} A ${radius} ${radius} 0 0 1 ${center + radius * 0.707} ${center - radius * 0.707} Z`;

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      {/* 脉冲外圈 */}
      <Animated.View
        style={[
          styles.pulseRing,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            borderColor: colors.scanGlow,
            transform: [{ scale: pulseAnim }],
          },
        ]}
      />
      {/* 雷达圈 */}
      <Svg width={size} height={size} style={styles.radar}>
        <Defs>
          <LinearGradient id="sweepGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <Stop offset="0%" stopColor={colors.primary} stopOpacity="0.6" />
            <Stop offset="100%" stopColor={colors.primary} stopOpacity="0" />
          </LinearGradient>
          <LinearGradient id="ringGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <Stop offset="0%" stopColor={colors.primary} stopOpacity="0.3" />
            <Stop offset="50%" stopColor={colors.primary} stopOpacity="0.8" />
            <Stop offset="100%" stopColor={colors.primary} stopOpacity="0.3" />
          </LinearGradient>
        </Defs>
        {/* 同心圆 */}
        <Circle
          cx={center}
          cy={center}
          r={radius * 0.3}
          stroke={colors.primary}
          strokeOpacity={0.2}
          strokeWidth={1}
          fill="none"
        />
        <Circle
          cx={center}
          cy={center}
          r={radius * 0.6}
          stroke={colors.primary}
          strokeOpacity={0.2}
          strokeWidth={1}
          fill="none"
        />
        <Circle
          cx={center}
          cy={center}
          r={radius}
          stroke="url(#ringGradient)"
          strokeWidth={2}
          fill="none"
        />
        {/* 十字线 */}
        <Path
          d={`M ${center} ${center - radius} L ${center} ${center + radius}`}
          stroke={colors.primary}
          strokeOpacity={0.15}
          strokeWidth={1}
        />
        <Path
          d={`M ${center - radius} ${center} L ${center + radius} ${center}`}
          stroke={colors.primary}
          strokeOpacity={0.15}
          strokeWidth={1}
        />
      </Svg>
      {/* 扫描扇形 */}
      {scanning && (
        <Animated.View
          style={[
            styles.sweepContainer,
            {
              width: size,
              height: size,
              transform: [{ rotate: spin }],
            },
          ]}
        >
          <Svg width={size} height={size}>
            <Path d={sweepPath} fill="url(#sweepGradient)" />
          </Svg>
        </Animated.View>
      )}
      {/* 中心点 */}
      <View style={[styles.centerDot, { backgroundColor: colors.primary }]} />
      {/* 标签 */}
      {label && (
        <View style={styles.labelContainer}>
          <Text style={[styles.labelText, { color: colors.textSecondary }]}>{label}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  pulseRing: {
    position: 'absolute',
    borderWidth: 2,
  },
  radar: {
    position: 'absolute',
  },
  sweepContainer: {
    position: 'absolute',
  },
  centerDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 10,
    elevation: 5,
  },
  labelContainer: {
    position: 'absolute',
    bottom: -30,
    alignItems: 'center',
  },
  labelText: {
    fontSize: 13,
  },
});
