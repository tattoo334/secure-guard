// 进度环组件 - 用于安全评分展示
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Svg, { Circle, Defs, LinearGradient, Stop } from 'react-native-svg';
import { useTheme } from '@hooks/useTheme';

interface ProgressRingProps {
  /** 进度值 0-100 */
  progress: number;
  /** 环的大小（直径） */
  size?: number;
  /** 环的宽度 */
  strokeWidth?: number;
  /** 中心标题 */
  title?: string;
  /** 中心副标题 */
  subtitle?: string;
  /** 是否显示百分比数字 */
  showPercent?: boolean;
}

export const ProgressRing: React.FC<ProgressRingProps> = ({
  progress,
  size = 180,
  strokeWidth = 14,
  title,
  subtitle,
  showPercent = true,
}) => {
  const { colors } = useTheme();

  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const clampedProgress = Math.max(0, Math.min(100, progress));
  const strokeDashoffset = circumference - (clampedProgress / 100) * circumference;

  // 根据进度获取颜色
  const getProgressColor = () => {
    if (clampedProgress >= 80) return colors.success;
    if (clampedProgress >= 50) return colors.warning;
    return colors.danger;
  };

  const progressColor = getProgressColor();
  const center = size / 2;

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      <Svg width={size} height={size}>
        <Defs>
          <LinearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <Stop offset="0%" stopColor={progressColor} stopOpacity="1" />
            <Stop offset="100%" stopColor={progressColor} stopOpacity="0.7" />
          </LinearGradient>
        </Defs>
        {/* 背景环 */}
        <Circle
          cx={center}
          cy={center}
          r={radius}
          stroke={colors.surfaceSecondary}
          strokeWidth={strokeWidth}
          fill="none"
        />
        {/* 进度环 */}
        <Circle
          cx={center}
          cy={center}
          r={radius}
          stroke="url(#progressGradient)"
          strokeWidth={strokeWidth}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          rotation={-90}
          origin={`${center}, ${center}`}
        />
      </Svg>
      {/* 中心内容 */}
      <View style={styles.centerContent}>
        {showPercent && (
          <Text style={[styles.percentText, { color: progressColor }]}>
            {Math.round(clampedProgress)}
          </Text>
        )}
        {title && <Text style={[styles.titleText, { color: colors.text }]}>{title}</Text>}
        {subtitle && (
          <Text style={[styles.subtitleText, { color: colors.textSecondary }]}>{subtitle}</Text>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerContent: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
  },
  percentText: {
    fontSize: 52,
    fontWeight: '800',
    lineHeight: 60,
  },
  titleText: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 2,
  },
  subtitleText: {
    fontSize: 12,
    marginTop: 2,
  },
});
