// 威胁卡片组件
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { Card } from '@components/ui/Card';
import { ThreatItem } from '@types/scan';
import { THREAT_TYPE_LABELS, THREAT_LEVEL_LABELS, THREAT_LEVEL_COLORS } from '@utils/constants';

interface ThreatCardProps {
  threat: ThreatItem;
  onResolve?: (threat: ThreatItem) => void;
  onIgnore?: (threat: ThreatItem) => void;
  onDetail?: (threat: ThreatItem) => void;
}

export const ThreatCard: React.FC<ThreatCardProps> = ({
  threat,
  onResolve,
  onIgnore,
  onDetail,
}) => {
  const { colors } = useTheme();
  const levelColor = THREAT_LEVEL_COLORS[threat.level];

  const getIconName = () => {
    switch (threat.type) {
      case 'virus':
        return 'bug-outline';
      case 'trojan':
        return 'skull-outline';
      case 'adware':
        return 'megaphone-outline';
      case 'spyware':
        return 'eye-off-outline';
      case 'ransomware':
        return 'lock-closed-outline';
      case 'risk_permission':
        return 'key-outline';
      case 'vulnerable_app':
        return 'alert-triangle-outline';
      case 'phishing':
        return 'fish-outline';
      default:
        return 'warning-outline';
    }
  };

  return (
    <Card style={[styles.card, threat.resolved && styles.resolvedCard]} padding={14}>
      <TouchableOpacity activeOpacity={0.7} onPress={() => onDetail?.(threat)}>
        <View style={styles.header}>
          <View style={[styles.iconContainer, { backgroundColor: levelColor + '20' }]}>
            <Ionicons name={getIconName() as any} size={22} color={levelColor} />
          </View>
          <View style={styles.headerText}>
            <Text style={[styles.threatName, { color: threat.resolved ? colors.textSecondary : colors.text }]}>
              {threat.name}
            </Text>
            <View style={styles.metaRow}>
              <View style={[styles.tag, { backgroundColor: levelColor + '15' }]}>
                <Text style={[styles.tagText, { color: levelColor }]}>
                  {THREAT_LEVEL_LABELS[threat.level]}
                </Text>
              </View>
              <Text style={[styles.metaText, { color: colors.textSecondary }]}>
                {THREAT_TYPE_LABELS[threat.type]}
              </Text>
              {threat.appName && (
                <Text style={[styles.metaText, { color: colors.textSecondary }]}>
                  · {threat.appName}
                </Text>
              )}
            </View>
          </View>
          {threat.resolved && (
            <View style={[styles.resolvedBadge, { backgroundColor: colors.success + '20' }]}>
              <Ionicons name="checkmark-circle" size={18} color={colors.success} />
            </View>
          )}
        </View>

        <Text style={[styles.description, { color: colors.textSecondary }]} numberOfLines={2}>
          {threat.description}
        </Text>

        {!threat.resolved && (
          <View style={styles.actionRow}>
            <TouchableOpacity
              style={[styles.actionButton, styles.resolveButton, { backgroundColor: colors.danger }]}
              onPress={() => onResolve?.(threat)}
            >
              <Ionicons name="trash-outline" size={16} color="#FFFFFF" />
              <Text style={styles.resolveText}>立即处理</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionButton, styles.ignoreButton]}
              onPress={() => onIgnore?.(threat)}
            >
              <Text style={[styles.ignoreText, { color: colors.textSecondary }]}>忽略</Text>
            </TouchableOpacity>
          </View>
        )}
      </TouchableOpacity>
    </Card>
  );
};

const styles = StyleSheet.create({
  card: {
    marginBottom: 10,
  },
  resolvedCard: {
    opacity: 0.7,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  headerText: {
    flex: 1,
  },
  threatName: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 4,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  tag: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
    marginRight: 8,
  },
  tagText: {
    fontSize: 11,
    fontWeight: '600',
  },
  metaText: {
    fontSize: 12,
  },
  resolvedBadge: {
    padding: 4,
    borderRadius: 12,
  },
  description: {
    fontSize: 13,
    lineHeight: 18,
    marginTop: 10,
  },
  actionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 8,
  },
  resolveButton: {
    marginRight: 10,
  },
  resolveText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '600',
    marginLeft: 6,
  },
  ignoreButton: {
    borderWidth: 1,
    borderColor: 'transparent',
  },
  ignoreText: {
    fontSize: 13,
  },
});
