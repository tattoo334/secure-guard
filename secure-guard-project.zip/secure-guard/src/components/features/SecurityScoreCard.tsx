// 安全评分卡片组件
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';
import { Card } from '@components/ui/Card';
import { ProgressRing } from '@components/ui/ProgressRing';
import { SecurityOverview } from '@types/security';
import { SECURITY_LEVEL_DESCRIPTIONS, SECURITY_LEVEL_COLORS } from '@utils/constants';
import { formatRelativeTime } from '@utils/format';

interface SecurityScoreCardProps {
  overview: SecurityOverview | null;
  onScanPress?: () => void;
}

export const SecurityScoreCard: React.FC<SecurityScoreCardProps> = ({ overview, onScanPress }) => {
  const { colors } = useTheme();

  const score = overview?.score ?? 0;
  const level = overview?.level ?? 'safe';
  const levelColor = SECURITY_LEVEL_COLORS[level];

  return (
    <Card style={styles.card}>
      <View style={styles.header}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>设备安全评分</Text>
        <View style={[styles.levelBadge, { backgroundColor: levelColor + '20' }]}>
          <Text style={[styles.levelText, { color: levelColor }]}>
            {level === 'safe' ? '安全' : level === 'warning' ? '警告' : '危险'}
          </Text>
        </View>
      </View>

      <View style={styles.scoreContainer}>
        <ProgressRing
          progress={score}
          size={160}
          strokeWidth={12}
          title="安全评分"
          subtitle={SECURITY_LEVEL_DESCRIPTIONS[level]}
        />
      </View>

      <View style={styles.statsRow}>
        <View style={styles.statItem}>
          <Ionicons name="apps-outline" size={18} color={colors.textSecondary} />
          <Text style={[styles.statValue, { color: colors.text }]}>{overview?.totalApps ?? 0}</Text>
          <Text style={[styles.statLabel, { color: colors.textSecondary }]}>已装应用</Text>
        </View>
        <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
        <View style={styles.statItem}>
          <Ionicons name="alert-circle-outline" size={18} color={colors.danger} />
          <Text style={[styles.statValue, { color: colors.danger }]}>{overview?.riskyApps ?? 0}</Text>
          <Text style={[styles.statLabel, { color: colors.textSecondary }]}>风险应用</Text>
        </View>
        <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
        <View style={styles.statItem}>
          <Ionicons name="time-outline" size={18} color={colors.textSecondary} />
          <Text style={[styles.statValue, { color: colors.text, fontSize: 12 }]}>
            {overview?.lastScanTime ? formatRelativeTime(overview.lastScanTime) : '未扫描'}
          </Text>
          <Text style={[styles.statLabel, { color: colors.textSecondary }]}>上次扫描</Text>
        </View>
      </View>
    </Card>
  );
};

const styles = StyleSheet.create({
  card: {
    marginBottom: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
  },
  levelBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  levelText: {
    fontSize: 13,
    fontWeight: '600',
  },
  scoreContainer: {
    alignItems: 'center',
    marginVertical: 8,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'transparent',
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  statValue: {
    fontSize: 18,
    fontWeight: '700',
    marginTop: 4,
  },
  statLabel: {
    fontSize: 11,
    marginTop: 2,
  },
  statDivider: {
    width: 1,
    height: 36,
  },
});
