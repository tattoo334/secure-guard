// 扫描进度条组件
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '@hooks/useTheme';

interface ScanProgressBarProps {
  progress: number;
  currentItem?: string | null;
  scannedCount?: number;
  totalCount?: number;
  threatCount?: number;
}

export const ScanProgressBar: React.FC<ScanProgressBarProps> = ({
  progress,
  currentItem,
  scannedCount,
  totalCount,
  threatCount,
}) => {
  const { colors } = useTheme();
  const clampedProgress = Math.max(0, Math.min(100, progress));

  return (
    <View style={styles.container}>
      <View style={styles.progressRow}>
        <Text style={[styles.progressText, { color: colors.text }]}>
          扫描中 {Math.round(clampedProgress)}%
        </Text>
        {scannedCount !== undefined && totalCount !== undefined && (
          <Text style={[styles.countText, { color: colors.textSecondary }]}>
            {scannedCount}/{totalCount}
          </Text>
        )}
      </View>
      <View style={[styles.track, { backgroundColor: colors.surfaceSecondary }]}>
        <View
          style={[
            styles.fill,
            {
              width: `${clampedProgress}%`,
              backgroundColor: colors.primary,
            },
          ]}
        />
      </View>
      <View style={styles.infoRow}>
        {currentItem && (
          <Text style={[styles.currentItem, { color: colors.textSecondary }]} numberOfLines={1}>
            正在扫描: {currentItem}
          </Text>
        )}
        {threatCount !== undefined && threatCount > 0 && (
          <View style={[styles.threatBadge, { backgroundColor: colors.danger + '20' }]}>
            <Text style={[styles.threatText, { color: colors.danger }]}>
              发现 {threatCount} 个威胁
            </Text>
          </View>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 8,
  },
  progressRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  progressText: {
    fontSize: 15,
    fontWeight: '600',
  },
  countText: {
    fontSize: 13,
  },
  track: {
    height: 8,
    borderRadius: 4,
    overflow: 'hidden',
  },
  fill: {
    height: '100%',
    borderRadius: 4,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  currentItem: {
    fontSize: 12,
    flex: 1,
  },
  threatBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
    marginLeft: 8,
  },
  threatText: {
    fontSize: 12,
    fontWeight: '600',
  },
});
