// 功能入口网格组件
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@hooks/useTheme';

export interface FeatureItem {
  id: string;
  icon: string;
  title: string;
  description?: string;
  color?: string;
  badge?: number | string;
  onPress: () => void;
}

interface FeatureGridProps {
  items: FeatureItem[];
  columns?: number;
}

export const FeatureGrid: React.FC<FeatureGridProps> = ({ items, columns = 4 }) => {
  const { colors } = useTheme();

  return (
    <View style={styles.container}>
      {items.map((item, index) => (
        <TouchableOpacity
          key={item.id}
          activeOpacity={0.7}
          style={[styles.item, { width: `${100 / columns}%` }]}
          onPress={item.onPress}
        >
          <View style={[styles.iconWrapper, { backgroundColor: (item.color || colors.primary) + '15' }]}>
            <Ionicons name={item.icon as any} size={24} color={item.color || colors.primary} />
            {item.badge !== undefined && (
              <View style={[styles.badge, { backgroundColor: colors.danger }]}>
                <Text style={styles.badgeText}>
                  {typeof item.badge === 'number' && item.badge > 99 ? '99+' : item.badge}
                </Text>
              </View>
            )}
          </View>
          <Text style={[styles.title, { color: colors.text }]} numberOfLines={1}>
            {item.title}
          </Text>
          {item.description && (
            <Text style={[styles.description, { color: colors.textSecondary }]} numberOfLines={1}>
              {item.description}
            </Text>
          )}
        </TouchableOpacity>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  item: {
    alignItems: 'center',
    paddingVertical: 12,
  },
  iconWrapper: {
    width: 52,
    height: 52,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
    position: 'relative',
  },
  badge: {
    position: 'absolute',
    top: -4,
    right: -4,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '700',
  },
  title: {
    fontSize: 13,
    fontWeight: '500',
    textAlign: 'center',
  },
  description: {
    fontSize: 10,
    marginTop: 2,
    textAlign: 'center',
  },
});
