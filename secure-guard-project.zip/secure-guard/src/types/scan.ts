// 扫描相关类型定义

/** 扫描类型 */
export type ScanType = 'quick' | 'full' | 'custom';

/** 扫描状态 */
export type ScanStatus = 'idle' | 'scanning' | 'paused' | 'completed' | 'cancelled';

/** 威胁等级 */
export type ThreatLevel = 'low' | 'medium' | 'high' | 'critical';

/** 威胁类型 */
export type ThreatType =
  | 'virus'
  | 'trojan'
  | 'adware'
  | 'spyware'
  | 'ransomware'
  | 'risk_permission'
  | 'vulnerable_app'
  | 'phishing';

/** 威胁项 */
export interface ThreatItem {
  id: string;
  /** 威胁名称 */
  name: string;
  /** 威胁类型 */
  type: ThreatType;
  /** 威胁等级 */
  level: ThreatLevel;
  /** 关联应用包名 */
  packageName?: string;
  /** 关联应用名称 */
  appName?: string;
  /** 文件路径 */
  filePath?: string;
  /** 威胁描述 */
  description: string;
  /** 建议操作 */
  recommendation: string;
  /** 是否已处理 */
  resolved: boolean;
  /** 发现时间 */
  discoveredAt: string;
}

/** 正在扫描的项目 */
export interface ScanningItem {
  id: string;
  name: string;
  type: 'app' | 'file' | 'system';
  path?: string;
  status: 'pending' | 'scanning' | 'clean' | 'threat';
}

/** 扫描结果 */
export interface ScanResult {
  /** 扫描类型 */
  scanType: ScanType;
  /** 扫描状态 */
  status: ScanStatus;
  /** 扫描进度 0-100 */
  progress: number;
  /** 已扫描项目数 */
  scannedCount: number;
  /** 总项目数 */
  totalCount: number;
  /** 发现威胁数 */
  threatCount: number;
  /** 扫描开始时间 */
  startTime: string | null;
  /** 扫描结束时间 */
  endTime: string | null;
  /** 扫描耗时（秒） */
  duration: number;
  /** 威胁列表 */
  threats: ThreatItem[];
  /** 当前正在扫描的项目 */
  currentItem: ScanningItem | null;
  /** 已扫描项目列表 */
  scannedItems: ScanningItem[];
}

/** 扫描历史记录 */
export interface ScanHistory {
  id: string;
  scanType: ScanType;
  startTime: string;
  duration: number;
  scannedCount: number;
  threatCount: number;
  resolved: boolean;
}
