// 应用管理相关类型

/** 已安装应用信息 */
export interface InstalledApp {
  id: string;
  /** 应用名称 */
  appName: string;
  /** 包名 */
  packageName: string;
  /** 版本号 */
  versionName: string;
  /** 版本代码 */
  versionCode: number;
  /** 应用大小（字节） */
  size: number;
  /** 缓存大小（字节） */
  cacheSize: number;
  /** 数据大小（字节） */
  dataSize: number;
  /** 安装时间 */
  installTime: string;
  /** 最后更新时间 */
  lastUpdateTime: string;
  /** 是否系统应用 */
  isSystemApp: boolean;
  /** 是否有风险 */
  isRisky: boolean;
  /** 风险描述 */
  riskDescription?: string;
  /** 权限列表 */
  permissions: AppPermission[];
  /** 应用图标（base64 或资源名） */
  icon?: string;
}

/** 应用权限 */
export interface AppPermission {
  /** 权限名称 */
  name: string;
  /** 权限描述 */
  description: string;
  /** 是否授权 */
  granted: boolean;
  /** 权限风险等级 */
  riskLevel: 'normal' | 'dangerous' | 'sensitive';
  /** 权限分组 */
  group: string;
}

/** 权限使用统计 */
export interface PermissionUsage {
  permission: string;
  /** 使用该权限的应用数量 */
  appCount: number;
  /** 应用列表 */
  apps: Array<{
    appName: string;
    packageName: string;
    lastUsedTime?: string;
  }>;
}
