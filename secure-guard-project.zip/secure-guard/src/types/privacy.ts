// 隐私保护相关类型

/** 应用锁状态 */
export interface AppLockState {
  /** 是否启用应用锁 */
  enabled: boolean;
  /** 锁定方式 */
  lockType: 'pattern' | 'pin' | 'biometric';
  /** 已锁定应用包名列表 */
  lockedApps: string[];
  /** 自动锁定延时（秒） */
  autoLockDelay: number;
  /** 隐藏通知内容 */
  hideNotifications: boolean;
}

/** 隐私泄露检测项 */
export interface PrivacyLeakItem {
  id: string;
  /** 检测项名称 */
  title: string;
  /** 检测类型 */
  type: 'account' | 'photo' | 'location' | 'clipboard' | 'network' | 'device';
  /** 风险等级 */
  riskLevel: 'low' | 'medium' | 'high';
  /** 描述 */
  description: string;
  /** 建议 */
  recommendation: string;
  /** 是否已修复 */
  fixed: boolean;
  /** 检测时间 */
  detectedAt: string;
}

/** 权限使用记录 */
export interface PermissionUsageLog {
  id: string;
  /** 应用包名 */
  packageName: string;
  /** 应用名称 */
  appName: string;
  /** 权限名称 */
  permission: string;
  /** 使用时间 */
  usedAt: string;
  /** 使用时长（秒） */
  duration: number;
  /** 前台/后台 */
  inForeground: boolean;
}

/** 虚拟定位配置 */
export interface VirtualLocationConfig {
  enabled: boolean;
  latitude: number;
  longitude: number;
  address: string;
}

/** 隐私保险箱文件 */
export interface VaultFile {
  id: string;
  /** 原始文件名 */
  originalName: string;
  /** 文件类型 */
  fileType: 'image' | 'video' | 'document' | 'other';
  /** 文件大小（字节） */
  size: number;
  /** 加密存储路径 */
  encryptedPath: string;
  /** 存入时间 */
  storedAt: string;
  /** 是否收藏 */
  favorite: boolean;
}
