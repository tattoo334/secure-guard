// 清理加速相关类型定义

/** 垃圾文件类型 */
export type JunkType =
  | 'cache'
  | 'apk'
  | 'temp'
  | 'thumbnail'
  | 'download'
  | 'empty_folder'
  | 'residual';

/** 垃圾文件项 */
export interface JunkFileItem {
  id: string;
  /** 文件/目录名称 */
  name: string;
  /** 类型 */
  type: JunkType;
  /** 所属应用包名 */
  packageName?: string;
  /** 所属应用名称 */
  appName?: string;
  /** 文件路径 */
  path: string;
  /** 大小（字节） */
  size: number;
  /** 文件数量 */
  fileCount: number;
  /** 是否选中清理 */
  selected: boolean;
  /** 安全等级：safe 可安全清理，caution 需确认 */
  safety: 'safe' | 'caution';
}

/** 垃圾分类汇总 */
export interface JunkCategory {
  type: JunkType;
  label: string;
  icon: string;
  totalSize: number;
  fileCount: number;
  items: JunkFileItem[];
}

/** 内存信息 */
export interface MemoryInfo {
  /** 总内存（字节） */
  totalMemory: number;
  /** 已用内存（字节） */
  usedMemory: number;
  /** 可用内存（字节） */
  availableMemory: number;
  /** 内存使用率 0-100 */
  usagePercent: number;
}

/** 正在运行的应用进程 */
export interface RunningProcess {
  id: string;
  appName: string;
  packageName: string;
  /** 占用内存（字节） */
  memoryUsage: number;
  /** CPU 使用率 0-100 */
  cpuUsage: number;
  /** 是否系统应用 */
  isSystemApp: boolean;
  /** 是否选中关闭 */
  selected: boolean;
}

/** 清理结果 */
export interface CleanResult {
  /** 释放空间（字节） */
  freedSpace: number;
  /** 清理文件数 */
  cleanedFiles: number;
  /** 关闭进程数 */
  killedProcesses: number;
  /** 释放内存（字节） */
  freedMemory: number;
  /** 清理时间 */
  completedAt: string;
}

/** 电池状态 */
export interface BatteryInfo {
  /** 电量百分比 0-100 */
  level: number;
  /** 是否充电中 */
  isCharging: boolean;
  /** 预计续航时间（分钟） */
  estimatedRemaining: number;
  /** 耗电应用列表 */
  powerHungryApps: Array<{
    appName: string;
    packageName: string;
    /** 耗电百分比 */
    powerPercent: number;
  }>;
}
