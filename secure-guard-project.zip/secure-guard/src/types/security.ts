// 安全相关类型定义

/** 安全等级 */
export type SecurityLevel = 'safe' | 'warning' | 'danger';

/** 安全评分概览 */
export interface SecurityOverview {
  /** 安全评分 0-100 */
  score: number;
  /** 安全等级 */
  level: SecurityLevel;
  /** 已安装应用总数 */
  totalApps: number;
  /** 风险应用数量 */
  riskyApps: number;
  /** 可清理垃圾大小（字节） */
  junkSize: number;
  /** 上次扫描时间 */
  lastScanTime: string | null;
  /** 实时防护是否开启 */
  realtimeProtection: boolean;
  /** 病毒库版本 */
  virusDbVersion: string;
}

/** 安全检测项 */
export interface SecurityCheckItem {
  id: string;
  title: string;
  description: string;
  status: 'passed' | 'warning' | 'failed' | 'pending';
  icon: string;
  riskLevel?: SecurityLevel;
}

/** 系统漏洞信息 */
export interface SystemVulnerability {
  id: string;
  title: string;
  cveId?: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  affectedVersion: string;
  patchStatus: 'patched' | 'available' | 'not_available';
  publishDate: string;
}
