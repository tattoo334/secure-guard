// 骚扰拦截相关类型

/** 拦截类型 */
export type BlockType = 'phone' | 'sms';

/** 拦截规则类型 */
export type BlockRuleType =
  | 'number'
  | 'prefix'
  | 'keyword'
  | 'category'
  | 'unknown';

/** 拦截规则 */
export interface BlockRule {
  id: string;
  /** 规则类型 */
  type: BlockRuleType;
  /** 规则值（号码、前缀、关键词等） */
  value: string;
  /** 规则描述 */
  description?: string;
  /** 是否启用 */
  enabled: boolean;
  /** 拦截次数 */
  blockCount: number;
  /** 创建时间 */
  createdAt: string;
}

/** 拦截记录 */
export interface BlockRecord {
  id: string;
  /** 拦截类型 */
  type: BlockType;
  /** 对方号码 */
  phoneNumber: string;
  /** 对方名称（如有） */
  contactName?: string;
  /** 短信内容（短信拦截时） */
  smsContent?: string;
  /** 拦截原因 */
  reason: string;
  /** 匹配的规则 ID */
  matchedRuleId?: string;
  /** 拦截时间 */
  blockedAt: string;
  /** 是否已读 */
  read: boolean;
  /** 标记类型 */
  markType?: 'harassment' | 'fraud' | 'advertising' | 'express' | 'other';
}

/** 骚扰电话标记统计 */
export interface PhoneMarkStats {
  /** 号码 */
  phoneNumber: string;
  /** 标记总数 */
  totalMarks: number;
  /** 各类型标记数 */
  marks: Record<string, number>;
  /** 是否建议拦截 */
  recommendBlock: boolean;
}
