// 骚扰拦截服务
import { BlockRule, BlockRecord } from '@types/block';
import { mockBlockRules, mockBlockRecords } from './mock/block';
import { delay, generateId } from '@utils/helpers';

class BlockService {
  private rules: BlockRule[] = [...mockBlockRules];
  private records: BlockRecord[] = [...mockBlockRecords];

  /** 获取拦截规则列表 */
  async getRules(): Promise<BlockRule[]> {
    await delay(200);
    return [...this.rules];
  }

  /** 添加拦截规则 */
  async addRule(rule: Omit<BlockRule, 'id' | 'createdAt' | 'blockCount'>): Promise<BlockRule> {
    await delay(300);
    const newRule: BlockRule = {
      ...rule,
      id: generateId(),
      createdAt: new Date().toISOString(),
      blockCount: 0,
    };
    this.rules.unshift(newRule);
    return newRule;
  }

  /** 更新拦截规则 */
  async updateRule(id: string, updates: Partial<BlockRule>): Promise<BlockRule | null> {
    await delay(200);
    const index = this.rules.findIndex((r) => r.id === id);
    if (index === -1) return null;
    this.rules[index] = { ...this.rules[index], ...updates };
    return this.rules[index];
  }

  /** 删除拦截规则 */
  async deleteRule(id: string): Promise<boolean> {
    await delay(200);
    const index = this.rules.findIndex((r) => r.id === id);
    if (index === -1) return false;
    this.rules.splice(index, 1);
    return true;
  }

  /** 切换规则启用状态 */
  async toggleRule(id: string): Promise<BlockRule | null> {
    const rule = this.rules.find((r) => r.id === id);
    if (!rule) return null;
    return this.updateRule(id, { enabled: !rule.enabled });
  }

  /** 获取拦截记录 */
  async getRecords(page = 1, pageSize = 20): Promise<{ records: BlockRecord[]; total: number }> {
    await delay(200);
    const start = (page - 1) * pageSize;
    const end = start + pageSize;
    return {
      records: this.records.slice(start, end),
      total: this.records.length,
    };
  }

  /** 标记记录已读 */
  async markAsRead(id: string): Promise<boolean> {
    await delay(100);
    const record = this.records.find((r) => r.id === id);
    if (record) {
      record.read = true;
      return true;
    }
    return false;
  }

  /** 全部标记已读 */
  async markAllAsRead(): Promise<number> {
    await delay(200);
    let count = 0;
    this.records.forEach((r) => {
      if (!r.read) {
        r.read = true;
        count++;
      }
    });
    return count;
  }

  /** 删除拦截记录 */
  async deleteRecord(id: string): Promise<boolean> {
    await delay(200);
    const index = this.records.findIndex((r) => r.id === id);
    if (index === -1) return false;
    this.records.splice(index, 1);
    return true;
  }

  /** 清空拦截记录 */
  async clearRecords(): Promise<boolean> {
    await delay(300);
    this.records = [];
    return true;
  }

  /** 获取未读数量 */
  getUnreadCount(): number {
    return this.records.filter((r) => !r.read).length;
  }

  /** 恢复号码（添加到白名单） */
  async whitelistNumber(phoneNumber: string): Promise<boolean> {
    await delay(300);
    // 模拟添加到白名单
    return true;
  }
}

export const blockService = new BlockService();
