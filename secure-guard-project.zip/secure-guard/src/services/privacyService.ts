// 隐私保护服务
import {
  PrivacyLeakItem,
  PermissionUsageLog,
  VaultFile,
  AppLockState,
} from '@types/privacy';
import {
  mockPrivacyLeaks,
  mockPermissionLogs,
  mockVaultFiles,
  mockAppLockState,
} from './mock/privacy';
import { delay, generateId } from '@utils/helpers';

class PrivacyService {
  private leaks: PrivacyLeakItem[] = [...mockPrivacyLeaks];
  private vaultFiles: VaultFile[] = [...mockVaultFiles];
  private appLockState: AppLockState = { ...mockAppLockState };

  /** 检测隐私泄露风险 */
  async detectPrivacyLeaks(): Promise<PrivacyLeakItem[]> {
    await delay(1500); // 模拟检测耗时
    return this.leaks.map((item) => ({ ...item }));
  }

  /** 修复隐私问题 */
  async fixLeak(id: string): Promise<boolean> {
    await delay(800);
    const leak = this.leaks.find((l) => l.id === id);
    if (leak) {
      leak.fixed = true;
      return true;
    }
    return false;
  }

  /** 获取权限使用记录 */
  async getPermissionLogs(): Promise<PermissionUsageLog[]> {
    await delay(300);
    return mockPermissionLogs.map((log) => ({ ...log }));
  }

  /** 获取应用锁状态 */
  async getAppLockState(): Promise<AppLockState> {
    await delay(100);
    return { ...this.appLockState };
  }

  /** 更新应用锁状态 */
  async updateAppLockState(updates: Partial<AppLockState>): Promise<AppLockState> {
    await delay(300);
    this.appLockState = { ...this.appLockState, ...updates };
    return { ...this.appLockState };
  }

  /** 切换应用锁 */
  async toggleAppLock(enabled: boolean): Promise<AppLockState> {
    return this.updateAppLockState({ enabled });
  }

  /** 添加锁定应用 */
  async addLockedApp(packageName: string): Promise<AppLockState> {
    if (!this.appLockState.lockedApps.includes(packageName)) {
      this.appLockState.lockedApps.push(packageName);
    }
    return { ...this.appLockState };
  }

  /** 移除锁定应用 */
  async removeLockedApp(packageName: string): Promise<AppLockState> {
    this.appLockState.lockedApps = this.appLockState.lockedApps.filter(
      (p) => p !== packageName
    );
    return { ...this.appLockState };
  }

  /** 获取保险箱文件 */
  async getVaultFiles(): Promise<VaultFile[]> {
    await delay(300);
    return this.vaultFiles.map((f) => ({ ...f }));
  }

  /** 添加文件到保险箱 */
  async addToVault(file: Omit<VaultFile, 'id' | 'encryptedPath' | 'storedAt'>): Promise<VaultFile> {
    await delay(1000); // 模拟加密耗时
    const newFile: VaultFile = {
      ...file,
      id: generateId(),
      encryptedPath: `/vault/${file.fileType}/${generateId()}.enc`,
      storedAt: new Date().toISOString(),
    };
    this.vaultFiles.unshift(newFile);
    return newFile;
  }

  /** 从保险箱移除文件 */
  async removeFromVault(id: string): Promise<boolean> {
    await delay(300);
    const index = this.vaultFiles.findIndex((f) => f.id === id);
    if (index === -1) return false;
    this.vaultFiles.splice(index, 1);
    return true;
  }

  /** 切换收藏 */
  async toggleFavorite(id: string): Promise<VaultFile | null> {
    await delay(100);
    const file = this.vaultFiles.find((f) => f.id === id);
    if (file) {
      file.favorite = !file.favorite;
      return { ...file };
    }
    return null;
  }

  /** 虚拟定位配置（Mock） */
  async getVirtualLocation(): Promise<{ enabled: boolean; address: string }> {
    await delay(200);
    return { enabled: false, address: '' };
  }
}

export const privacyService = new PrivacyService();
