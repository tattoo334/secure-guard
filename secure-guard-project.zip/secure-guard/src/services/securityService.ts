// 安全概览服务
import { SecurityOverview, SecurityCheckItem, SystemVulnerability } from '@types/security';
import { mockInstalledApps } from './mock/apps';
import { mockJunkFiles } from './mock/junkFiles';
import { DEFAULT_VIRUS_DB_VERSION } from '@utils/constants';
import { delay } from '@utils/helpers';

class SecurityService {
  /** 获取安全概览 */
  async getSecurityOverview(): Promise<SecurityOverview> {
    await delay(300);

    const riskyApps = mockInstalledApps.filter((app) => app.isRisky).length;
    const junkSize = mockJunkFiles.reduce((sum, item) => sum + item.size, 0);

    // 根据风险项计算安全评分
    let score = 100;
    score -= riskyApps * 15;
    score -= Math.min(junkSize / 104857600, 10); // 每100MB扣1分，最多扣10分
    score = Math.max(0, Math.min(100, Math.round(score)));

    const level = score >= 80 ? 'safe' : score >= 50 ? 'warning' : 'danger';

    return {
      score,
      level,
      totalApps: mockInstalledApps.length,
      riskyApps,
      junkSize,
      lastScanTime: '2026-09-30T20:00:00Z',
      realtimeProtection: true,
      virusDbVersion: DEFAULT_VIRUS_DB_VERSION,
    };
  }

  /** 获取安全检测项列表 */
  async getSecurityChecks(): Promise<SecurityCheckItem[]> {
    await delay(400);

    return [
      {
        id: 'virus_db',
        title: '病毒库已更新',
        description: `当前病毒库版本 ${DEFAULT_VIRUS_DB_VERSION}`,
        status: 'passed',
        icon: 'shield-checkmark-outline',
      },
      {
        id: 'realtime_protection',
        title: '实时防护已开启',
        description: '全天候监控应用安装和文件变化',
        status: 'passed',
        icon: 'eye-outline',
      },
      {
        id: 'risky_apps',
        title: '风险应用检测',
        description: `发现 ${mockInstalledApps.filter((a) => a.isRisky).length} 个风险应用`,
        status: 'failed',
        icon: 'alert-triangle-outline',
        riskLevel: 'danger',
      },
      {
        id: 'system_update',
        title: '系统安全更新',
        description: '系统存在未安装的安全补丁',
        status: 'warning',
        icon: 'cloud-download-outline',
        riskLevel: 'warning',
      },
      {
        id: 'screen_lock',
        title: '屏幕锁定已设置',
        description: '设备已启用密码/指纹锁定',
        status: 'passed',
        icon: 'lock-closed-outline',
      },
      {
        id: 'encryption',
        title: '设备加密',
        description: '设备存储已启用加密保护',
        status: 'passed',
        icon: 'key-outline',
      },
      {
        id: 'adb_debug',
        title: 'USB调试模式',
        description: 'USB调试已关闭，设备安全',
        status: 'passed',
        icon: 'hardware-chip-outline',
      },
      {
        id: 'unknown_sources',
        title: '未知来源安装',
        description: '已禁止安装未知来源应用',
        status: 'passed',
        icon: 'ban-outline',
      },
    ];
  }

  /** 获取系统漏洞列表 */
  async getSystemVulnerabilities(): Promise<SystemVulnerability[]> {
    await delay(500);

    return [
      {
        id: 'v1',
        title: 'Android 系统组件提权漏洞',
        cveId: 'CVE-2026-1234',
        severity: 'high',
        description: '系统服务中存在提权漏洞，恶意应用可利用此漏洞获取系统级权限',
        affectedVersion: 'Android 14 及以下',
        patchStatus: 'available',
        publishDate: '2026-09-15',
      },
      {
        id: 'v2',
        title: '媒体框架远程代码执行漏洞',
        cveId: 'CVE-2026-2345',
        severity: 'critical',
        description: '媒体解析库存在缓冲区溢出漏洞，攻击者可通过特制媒体文件执行远程代码',
        affectedVersion: 'Android 12-14',
        patchStatus: 'available',
        publishDate: '2026-09-20',
      },
      {
        id: 'v3',
        title: '蓝牙协议信息泄露漏洞',
        cveId: 'CVE-2026-3456',
        severity: 'medium',
        description: '蓝牙协议实现中存在信息泄露漏洞，附近攻击者可获取设备部分敏感信息',
        affectedVersion: 'Android 13-14',
        patchStatus: 'patched',
        publishDate: '2026-08-10',
      },
    ];
  }

  /** 更新病毒库（模拟） */
  async updateVirusDatabase(): Promise<{ success: boolean; version: string }> {
    await delay(2000);
    return {
      success: true,
      version: DEFAULT_VIRUS_DB_VERSION,
    };
  }
}

export const securityService = new SecurityService();
