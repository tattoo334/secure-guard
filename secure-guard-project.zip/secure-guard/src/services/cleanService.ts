// 清理加速服务
import {
  JunkFileItem,
  JunkCategory,
  RunningProcess,
  MemoryInfo,
  BatteryInfo,
  CleanResult,
} from '@types/clean';
import {
  mockJunkFiles,
  getJunkCategories,
  mockRunningProcesses,
  mockMemoryInfo,
  mockBatteryInfo,
} from './mock/junkFiles';
import { delay, generateId } from '@utils/helpers';

class CleanService {
  /** 获取垃圾文件列表 */
  async getJunkFiles(): Promise<JunkFileItem[]> {
    await delay(500); // 模拟扫描耗时
    return mockJunkFiles.map((item) => ({ ...item }));
  }

  /** 获取垃圾分类 */
  async getJunkCategories(): Promise<JunkCategory[]> {
    await delay(300);
    return getJunkCategories();
  }

  /** 执行垃圾清理 */
  async cleanJunkFiles(items: JunkFileItem[]): Promise<CleanResult> {
    const selectedItems = items.filter((item) => item.selected);
    const freedSpace = selectedItems.reduce((sum, item) => sum + item.size, 0);
    const cleanedFiles = selectedItems.reduce((sum, item) => sum + item.fileCount, 0);

    // 模拟清理过程
    for (let i = 0; i < selectedItems.length; i++) {
      await delay(100);
    }

    return {
      freedSpace,
      cleanedFiles,
      killedProcesses: 0,
      freedMemory: 0,
      completedAt: new Date().toISOString(),
    };
  }

  /** 获取运行中进程 */
  async getRunningProcesses(): Promise<RunningProcess[]> {
    await delay(300);
    return mockRunningProcesses.map((p) => ({ ...p }));
  }

  /** 关闭选中进程 */
  async killProcesses(processes: RunningProcess[]): Promise<CleanResult> {
    const selected = processes.filter((p) => p.selected && !p.isSystemApp);
    const freedMemory = selected.reduce((sum, p) => sum + p.memoryUsage, 0);

    await delay(800);

    return {
      freedSpace: 0,
      cleanedFiles: 0,
      killedProcesses: selected.length,
      freedMemory,
      completedAt: new Date().toISOString(),
    };
  }

  /** 获取内存信息 */
  async getMemoryInfo(): Promise<MemoryInfo> {
    await delay(200);
    return { ...mockMemoryInfo };
  }

  /** 获取电池信息 */
  async getBatteryInfo(): Promise<BatteryInfo> {
    await delay(200);
    return {
      ...mockBatteryInfo,
      powerHungryApps: mockBatteryInfo.powerHungryApps.map((a) => ({ ...a })),
    };
  }

  /** 一键优化（清理垃圾 + 关闭进程） */
  async oneTapBoost(): Promise<CleanResult> {
    const [junkResult, processResult] = await Promise.all([
      this.cleanJunkFiles(mockJunkFiles),
      this.killProcesses(mockRunningProcesses),
    ]);

    return {
      freedSpace: junkResult.freedSpace,
      cleanedFiles: junkResult.cleanedFiles,
      killedProcesses: processResult.killedProcesses,
      freedMemory: processResult.freedMemory,
      completedAt: new Date().toISOString(),
    };
  }
}

export const cleanService = new CleanService();
