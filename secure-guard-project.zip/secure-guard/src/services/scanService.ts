// 扫描服务 - 模拟病毒扫描引擎
import { ScanType, ScanResult, ThreatItem, ScanningItem, ScanHistory } from '@types/scan';
import { mockInstalledApps } from './mock/apps';
import { mockThreats } from './mock/threats';
import { delay, generateId, randomInt } from '@utils/helpers';
import { SCAN_CONFIG } from '@utils/constants';

export type ScanProgressCallback = (progress: number, currentItem: ScanningItem | null) => void;

/**
 * 扫描服务
 * 模拟真实杀毒引擎的扫描流程
 */
class ScanService {
  private isScanning = false;
  private shouldCancel = false;
  private shouldPause = false;

  /** 检查是否正在扫描 */
  getIsScanning(): boolean {
    return this.isScanning;
  }

  /** 取消扫描 */
  cancel(): void {
    this.shouldCancel = true;
    this.shouldPause = false;
  }

  /** 暂停扫描 */
  pause(): void {
    this.shouldPause = true;
  }

  /** 恢复扫描 */
  resume(): void {
    this.shouldPause = false;
  }

  /**
   * 执行扫描
   * @param scanType 扫描类型
   * @param onProgress 进度回调
   */
  async startScan(
    scanType: ScanType,
    onProgress?: ScanProgressCallback
  ): Promise<ScanResult> {
    if (this.isScanning) {
      throw new Error('已有扫描任务正在进行');
    }

    this.isScanning = true;
    this.shouldCancel = false;
    this.shouldPause = false;

    const startTime = new Date().toISOString();
    const apps = mockInstalledApps.filter((app) => !app.isSystemApp);
    const scanItems = this.buildScanItems(scanType, apps);
    const totalCount = scanItems.length;
    const threats: ThreatItem[] = [];
    const scannedItems: ScanningItem[] = [];

    let currentItem: ScanningItem | null = null;

    for (let i = 0; i < scanItems.length; i++) {
      // 检查取消
      if (this.shouldCancel) break;

      // 检查暂停
      while (this.shouldPause && !this.shouldCancel) {
        await delay(200);
      }

      currentItem = { ...scanItems[i], status: 'scanning' };
      onProgress?.(Math.round((i / totalCount) * 100), currentItem);

      // 模拟扫描耗时
      await delay(SCAN_CONFIG.fullScanDelayMs + randomInt(0, 100));

      // 检测威胁
      const threat = this.detectThreat(scanItems[i]);
      if (threat) {
        threats.push(threat);
        currentItem = { ...currentItem, status: 'threat' };
      } else {
        currentItem = { ...currentItem, status: 'clean' };
      }

      scannedItems.push(currentItem);
      onProgress?.(Math.round(((i + 1) / totalCount) * 100), currentItem);
    }

    const endTime = new Date().toISOString();
    const duration = Math.round((new Date(endTime).getTime() - new Date(startTime).getTime()) / 1000);

    this.isScanning = false;

    return {
      scanType,
      status: this.shouldCancel ? 'cancelled' : 'completed',
      progress: this.shouldCancel ? Math.round((scannedItems.length / totalCount) * 100) : 100,
      scannedCount: scannedItems.length,
      totalCount,
      threatCount: threats.length,
      startTime,
      endTime,
      duration,
      threats,
      currentItem: null,
      scannedItems,
    };
  }

  /** 构建扫描项目列表 */
  private buildScanItems(scanType: ScanType, apps: typeof mockInstalledApps): ScanningItem[] {
    const items: ScanningItem[] = [];

    const targetApps = scanType === 'quick' ? apps.slice(0, SCAN_CONFIG.quickScanAppLimit) : apps;

    // 应用扫描
    targetApps.forEach((app) => {
      items.push({
        id: generateId(),
        name: app.appName,
        type: 'app',
        path: app.packageName,
        status: 'pending',
      });
    });

    if (scanType === 'full') {
      // 系统文件扫描
      const systemPaths = [
        '/system/app',
        '/system/priv-app',
        '/data/app',
        '/sdcard/Download',
        '/sdcard/Android/data',
        '/sdcard/DCIM',
        '/sdcard/Documents',
      ];
      systemPaths.forEach((path) => {
        items.push({
          id: generateId(),
          name: path.split('/').pop() || path,
          type: 'file',
          path,
          status: 'pending',
        });
      });
    }

    return items;
  }

  /** 检测威胁（模拟特征码匹配） */
  private detectThreat(item: ScanningItem): ThreatItem | null {
    // 根据包名匹配 Mock 威胁
    const matchingThreat = mockThreats.find(
      (t) => t.packageName === item.path
    );

    if (matchingThreat) {
      return {
        ...matchingThreat,
        id: generateId(),
        discoveredAt: new Date().toISOString(),
      };
    }

    // 全盘扫描有小概率发现文件型威胁
    if (item.type === 'file' && Math.random() < 0.05) {
      return {
        id: generateId(),
        name: 'Suspicious.File.Generic',
        type: 'virus',
        level: 'medium',
        filePath: item.path,
        description: '该文件包含可疑代码特征，可能存在安全风险',
        recommendation: '建议删除该文件或上传至云端进行深度分析',
        resolved: false,
        discoveredAt: new Date().toISOString(),
      };
    }

    return null;
  }

  /** 获取扫描历史（Mock） */
  getScanHistory(): ScanHistory[] {
    return [
      {
        id: 'h1',
        scanType: 'full',
        startTime: '2026-09-30T20:00:00Z',
        duration: 185,
        scannedCount: 45,
        threatCount: 2,
        resolved: true,
      },
      {
        id: 'h2',
        scanType: 'quick',
        startTime: '2026-09-29T08:30:00Z',
        duration: 45,
        scannedCount: 20,
        threatCount: 0,
        resolved: true,
      },
      {
        id: 'h3',
        scanType: 'full',
        startTime: '2026-09-25T21:00:00Z',
        duration: 210,
        scannedCount: 48,
        threatCount: 1,
        resolved: true,
      },
    ];
  }
}

export const scanService = new ScanService();
