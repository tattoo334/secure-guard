// Mock 威胁数据
import { ThreatItem } from '@types/scan';

export const mockThreats: ThreatItem[] = [
  {
    id: 't1',
    name: 'Android.Trojan.SmsSend',
    type: 'trojan',
    level: 'critical',
    packageName: 'com.clean.master.lite',
    appName: '清理大师极速版',
    description: '该木马会在后台静默发送付费短信，造成资费消耗，并可能上传通讯录和短信内容到远程服务器',
    recommendation: '立即卸载该应用，并检查近期话费账单是否有异常扣费',
    resolved: false,
    discoveredAt: '2026-10-01T08:30:00Z',
  },
  {
    id: 't2',
    name: '隐私风险-过度收集通讯录',
    type: 'risk_permission',
    level: 'high',
    packageName: 'com.snda.wifilocating',
    appName: 'WiFi万能钥匙',
    description: '该应用在非必要场景下持续读取通讯录数据，并将数据上传至第三方服务器，存在隐私泄露风险',
    recommendation: '禁用通讯录权限或卸载该应用，建议使用系统自带WiFi功能',
    resolved: false,
    discoveredAt: '2026-10-01T08:30:05Z',
  },
  {
    id: 't3',
    name: 'Adware.PopupAds',
    type: 'adware',
    level: 'medium',
    packageName: 'com.clean.master.lite',
    appName: '清理大师极速版',
    description: '该应用包含广告插件，会在通知栏和桌面推送广告，影响使用体验并可能消耗流量',
    recommendation: '卸载该应用或使用广告拦截功能',
    resolved: false,
    discoveredAt: '2026-10-01T08:30:10Z',
  },
  {
    id: 't4',
    name: '后台自启动风险',
    type: 'risk_permission',
    level: 'low',
    packageName: 'com.sankuai.meituan',
    appName: '美团',
    description: '该应用注册了多个自启动广播接收器，可能在后台频繁唤醒，影响电量和内存',
    recommendation: '在系统设置中限制后台活动，或使用本应用的自启动管理功能',
    resolved: false,
    discoveredAt: '2026-10-01T08:30:15Z',
  },
];

/** 病毒特征库（Mock） */
export const mockVirusSignatures = [
  { signature: 'Android.Trojan.SmsSend', name: '短信发送木马', type: 'trojan', level: 'critical' },
  { signature: 'Android.Spy.KeyLogger', name: '键盘记录间谍', type: 'spyware', level: 'high' },
  { signature: 'Android.Ransom.CryptoLocker', name: '加密勒索软件', type: 'ransomware', level: 'critical' },
  { signature: 'Android.Adware.Popup', name: '弹窗广告软件', type: 'adware', level: 'medium' },
  { signature: 'Android.Phishing.Bank', name: '银行钓鱼木马', type: 'phishing', level: 'critical' },
];
