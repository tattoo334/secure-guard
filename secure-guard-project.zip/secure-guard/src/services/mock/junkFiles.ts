// Mock 垃圾文件数据
import { JunkFileItem, JunkCategory, RunningProcess, MemoryInfo, BatteryInfo } from '@types/clean';

export const mockJunkFiles: JunkFileItem[] = [
  // 应用缓存
  {
    id: 'j1',
    name: '微信缓存',
    type: 'cache',
    packageName: 'com.tencent.mm',
    appName: '微信',
    path: '/sdcard/Android/data/com.tencent.mm/cache',
    size: 314572800,
    fileCount: 1256,
    selected: true,
    safety: 'safe',
  },
  {
    id: 'j2',
    name: '抖音缓存',
    type: 'cache',
    packageName: 'com.ss.android.ugc.aweme',
    appName: '抖音',
    path: '/sdcard/Android/data/com.ss.android.ugc.aweme/cache',
    size: 524288000,
    fileCount: 3420,
    selected: true,
    safety: 'safe',
  },
  {
    id: 'j3',
    name: '淘宝缓存',
    type: 'cache',
    packageName: 'com.taobao.taobao',
    appName: '淘宝',
    path: '/sdcard/Android/data/com.taobao.taobao/cache',
    size: 209715200,
    fileCount: 890,
    selected: true,
    safety: 'safe',
  },
  {
    id: 'j4',
    name: '高德地图缓存',
    type: 'cache',
    packageName: 'com.autonavi.minimap',
    appName: '高德地图',
    path: '/sdcard/Android/data/com.autonavi.minimap/cache',
    size: 314572800,
    fileCount: 560,
    selected: true,
    safety: 'safe',
  },
  // 安装包
  {
    id: 'j5',
    name: 'weixin_8.0.49.apk',
    type: 'apk',
    path: '/sdcard/Download/weixin_8.0.49.apk',
    size: 268435456,
    fileCount: 1,
    selected: true,
    safety: 'safe',
  },
  {
    id: 'j6',
    name: 'douyin_28.5.0.apk',
    type: 'apk',
    path: '/sdcard/Download/douyin_28.5.0.apk',
    size: 314572800,
    fileCount: 1,
    selected: true,
    safety: 'safe',
  },
  // 临时文件
  {
    id: 'j7',
    name: '系统临时文件',
    type: 'temp',
    path: '/sdcard/tmp',
    size: 52428800,
    fileCount: 234,
    selected: true,
    safety: 'safe',
  },
  // 缩略图
  {
    id: 'j8',
    name: '相册缩略图缓存',
    type: 'thumbnail',
    path: '/sdcard/DCIM/.thumbnails',
    size: 157286400,
    fileCount: 5680,
    selected: true,
    safety: 'safe',
  },
  // 下载文件
  {
    id: 'j9',
    name: '旧下载文件',
    type: 'download',
    path: '/sdcard/Download/old_files',
    size: 209715200,
    fileCount: 15,
    selected: false,
    safety: 'caution',
  },
  // 卸载残留
  {
    id: 'j10',
    name: '某游戏卸载残留',
    type: 'residual',
    path: '/sdcard/Android/data/com.game.removed',
    size: 419430400,
    fileCount: 89,
    selected: true,
    safety: 'safe',
  },
  {
    id: 'j11',
    name: '某视频App卸载残留',
    type: 'residual',
    path: '/sdcard/Android/data/com.video.removed',
    size: 268435456,
    fileCount: 45,
    selected: true,
    safety: 'safe',
  },
];

/** 按类型分组的垃圾数据 */
export function getJunkCategories(): JunkCategory[] {
  const typeMap: Record<string, JunkFileItem[]> = {};
  mockJunkFiles.forEach((item) => {
    if (!typeMap[item.type]) typeMap[item.type] = [];
    typeMap[item.type].push(item);
  });

  const labelMap: Record<string, string> = {
    cache: '应用缓存',
    apk: '安装包',
    temp: '临时文件',
    thumbnail: '缩略图',
    download: '下载文件',
    empty_folder: '空文件夹',
    residual: '卸载残留',
  };

  const iconMap: Record<string, string> = {
    cache: 'archive-outline',
    apk: 'apk-outline',
    temp: 'file-tray-full-outline',
    thumbnail: 'images-outline',
    download: 'download-outline',
    empty_folder: 'folder-open-outline',
    residual: 'trash-bin-outline',
  };

  return Object.entries(typeMap).map(([type, items]) => ({
    type: type as JunkCategory['type'],
    label: labelMap[type] || type,
    icon: iconMap[type] || 'folder-outline',
    totalSize: items.reduce((sum, item) => sum + item.size, 0),
    fileCount: items.reduce((sum, item) => sum + item.fileCount, 0),
    items,
  }));
}

/** Mock 运行中进程 */
export const mockRunningProcesses: RunningProcess[] = [
  {
    id: 'p1',
    appName: '微信',
    packageName: 'com.tencent.mm',
    memoryUsage: 419430400,
    cpuUsage: 5,
    isSystemApp: false,
    selected: true,
  },
  {
    id: 'p2',
    appName: '抖音',
    packageName: 'com.ss.android.ugc.aweme',
    memoryUsage: 524288000,
    cpuUsage: 8,
    isSystemApp: false,
    selected: true,
  },
  {
    id: 'p3',
    appName: '淘宝',
    packageName: 'com.taobao.taobao',
    memoryUsage: 314572800,
    cpuUsage: 3,
    isSystemApp: false,
    selected: true,
  },
  {
    id: 'p4',
    appName: '美团',
    packageName: 'com.sankuai.meituan',
    memoryUsage: 209715200,
    cpuUsage: 2,
    isSystemApp: false,
    selected: false,
  },
  {
    id: 'p5',
    appName: '高德地图',
    packageName: 'com.autonavi.minimap',
    memoryUsage: 268435456,
    cpuUsage: 4,
    isSystemApp: false,
    selected: false,
  },
  {
    id: 'p6',
    appName: '系统界面',
    packageName: 'com.android.systemui',
    memoryUsage: 314572800,
    cpuUsage: 6,
    isSystemApp: true,
    selected: false,
  },
];

/** Mock 内存信息 */
export const mockMemoryInfo: MemoryInfo = {
  totalMemory: 8589934592, // 8GB
  usedMemory: 6012954214, // ~5.6GB
  availableMemory: 2576980378, // ~2.4GB
  usagePercent: 70,
};

/** Mock 电池信息 */
export const mockBatteryInfo: BatteryInfo = {
  level: 65,
  isCharging: false,
  estimatedRemaining: 480, // 8小时
  powerHungryApps: [
    { appName: '抖音', packageName: 'com.ss.android.ugc.aweme', powerPercent: 18 },
    { appName: '微信', packageName: 'com.tencent.mm', powerPercent: 12 },
    { appName: '高德地图', packageName: 'com.autonavi.minimap', powerPercent: 8 },
    { appName: '淘宝', packageName: 'com.taobao.taobao', powerPercent: 5 },
  ],
};
