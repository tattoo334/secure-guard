// 应用管理服务
import { InstalledApp, PermissionUsage } from '@types/app';
import { mockInstalledApps } from './mock/apps';
import { delay } from '@utils/helpers';

class AppService {
  /** 获取所有已安装应用 */
  async getInstalledApps(includeSystem = true): Promise<InstalledApp[]> {
    await delay(300);
    const apps = includeSystem
      ? mockInstalledApps
      : mockInstalledApps.filter((app) => !app.isSystemApp);
    return apps.map((app) => ({ ...app }));
  }

  /** 获取风险应用 */
  async getRiskyApps(): Promise<InstalledApp[]> {
    await delay(200);
    return mockInstalledApps.filter((app) => app.isRisky).map((app) => ({ ...app }));
  }

  /** 获取应用详情 */
  async getAppDetail(packageName: string): Promise<InstalledApp | null> {
    await delay(100);
    const app = mockInstalledApps.find((a) => a.packageName === packageName);
    return app ? { ...app } : null;
  }

  /** 获取权限使用统计 */
  async getPermissionUsage(): Promise<PermissionUsage[]> {
    await delay(300);

    const permissionMap: Record<string, PermissionUsage> = {};

    mockInstalledApps.forEach((app) => {
      app.permissions.forEach((perm) => {
        if (!permissionMap[perm.name]) {
          permissionMap[perm.name] = {
            permission: perm.name,
            appCount: 0,
            apps: [],
          };
        }
        if (perm.granted) {
          permissionMap[perm.name].appCount++;
          permissionMap[perm.name].apps.push({
            appName: app.appName,
            packageName: app.packageName,
          });
        }
      });
    });

    return Object.values(permissionMap).sort((a, b) => b.appCount - a.appCount);
  }

  /** 卸载应用（模拟） */
  async uninstallApp(packageName: string): Promise<boolean> {
    await delay(1000);
    // 模拟卸载成功
    return true;
  }

  /** 清除应用缓存（模拟） */
  async clearAppCache(packageName: string): Promise<number> {
    await delay(500);
    const app = mockInstalledApps.find((a) => a.packageName === packageName);
    return app?.cacheSize || 0;
  }
}

export const appService = new AppService();
