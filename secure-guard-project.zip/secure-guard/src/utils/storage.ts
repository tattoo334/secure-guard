// 本地存储封装
import AsyncStorage from '@react-native-async-storage/async-storage';

/** 存储键名常量 */
export const StorageKeys = {
  SECURITY_OVERVIEW: 'security_overview',
  SCAN_HISTORY: 'scan_history',
  SCAN_RESULT: 'scan_result',
  BLOCK_RULES: 'block_rules',
  BLOCK_RECORDS: 'block_records',
  APP_LOCK_STATE: 'app_lock_state',
  SETTINGS: 'app_settings',
  THREAT_IGNORE_LIST: 'threat_ignore_list',
  WHITE_LIST_APPS: 'white_list_apps',
} as const;

export type StorageKey = (typeof StorageKeys)[keyof typeof StorageKeys];

/**
 * 通用存储工具
 */
export const storage = {
  /** 获取数据 */
  async get<T>(key: StorageKey | string): Promise<T | null> {
    try {
      const value = await AsyncStorage.getItem(key);
      return value ? (JSON.parse(value) as T) : null;
    } catch (error) {
      console.error(`[Storage] 获取失败 key=${key}:`, error);
      return null;
    }
  },

  /** 保存数据 */
  async set(key: StorageKey | string, value: unknown): Promise<boolean> {
    try {
      await AsyncStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      console.error(`[Storage] 保存失败 key=${key}:`, error);
      return false;
    }
  },

  /** 删除数据 */
  async remove(key: StorageKey | string): Promise<boolean> {
    try {
      await AsyncStorage.removeItem(key);
      return true;
    } catch (error) {
      console.error(`[Storage] 删除失败 key=${key}:`, error);
      return false;
    }
  },

  /** 清空所有数据 */
  async clear(): Promise<boolean> {
    try {
      await AsyncStorage.clear();
      return true;
    } catch (error) {
      console.error('[Storage] 清空失败:', error);
      return false;
    }
  },

  /** 获取所有键 */
  async getAllKeys(): Promise<string[]> {
    try {
      return await AsyncStorage.getAllKeys();
    } catch {
      return [];
    }
  },

  /** 批量获取 */
  async multiGet<T>(keys: string[]): Promise<Record<string, T | null>> {
    try {
      const pairs = await AsyncStorage.multiGet(keys);
      const result: Record<string, T | null> = {};
      pairs.forEach(([key, value]) => {
        result[key] = value ? (JSON.parse(value) as T) : null;
      });
      return result;
    } catch {
      return {};
    }
  },
};
