// 应用常量配置

/** 威胁类型中文映射 */
export const THREAT_TYPE_LABELS: Record<string, string> = {
  virus: '病毒',
  trojan: '木马',
  adware: '广告软件',
  spyware: '间谍软件',
  ransomware: '勒索软件',
  risk_permission: '风险权限',
  vulnerable_app: '漏洞应用',
  phishing: '钓鱼攻击',
};

/** 威胁等级中文映射 */
export const THREAT_LEVEL_LABELS: Record<string, string> = {
  low: '低危',
  medium: '中危',
  high: '高危',
  critical: '严重',
};

/** 威胁等级颜色 */
export const THREAT_LEVEL_COLORS: Record<string, string> = {
  low: '#FFC107',
  medium: '#FF9800',
  high: '#F44336',
  critical: '#B71C1C',
};

/** 垃圾类型中文映射 */
export const JUNK_TYPE_LABELS: Record<string, string> = {
  cache: '应用缓存',
  apk: '安装包',
  temp: '临时文件',
  thumbnail: '缩略图',
  download: '下载文件',
  empty_folder: '空文件夹',
  residual: '卸载残留',
};

/** 扫描类型中文映射 */
export const SCAN_TYPE_LABELS: Record<string, string> = {
  quick: '快速扫描',
  full: '全盘扫描',
  custom: '自定义扫描',
};

/** 安全等级颜色映射 */
export const SECURITY_LEVEL_COLORS: Record<string, string> = {
  safe: '#4CAF50',
  warning: '#FF9800',
  danger: '#F44336',
};

/** 安全等级描述 */
export const SECURITY_LEVEL_DESCRIPTIONS: Record<string, string> = {
  safe: '设备安全，继续保持',
  warning: '存在风险项，建议尽快处理',
  danger: '设备面临严重威胁，请立即处理',
};

/** 默认应用设置 */
export const DEFAULT_SETTINGS = {
  realtimeProtection: true,
  autoUpdateVirusDb: true,
  autoScanOnWifi: false,
  notificationEnabled: true,
  darkMode: 'system' as 'system' | 'light' | 'dark',
  ignoreSystemApps: true,
  quarantineThreats: true,
  scanSdCard: true,
  scanInstalledApps: true,
  scanDownloadFolder: true,
  blockUnknownCalls: false,
  blockSpamSms: true,
  appLockEnabled: false,
  hideSensitiveNotifications: true,
} as const;

/** 病毒库默认版本 */
export const DEFAULT_VIRUS_DB_VERSION = '2026.10.01';

/** 扫描配置 */
export const SCAN_CONFIG = {
  quickScanAppLimit: 30,
  fullScanDelayMs: 50,
  progressUpdateIntervalMs: 100,
} as const;
