// 应用数据加载 Hook
import { useEffect, useCallback } from 'react';
import { useSecurityStore } from '@store/securityStore';
import { useScanStore } from '@store/scanStore';

export function useAppData() {
  const { overview, fetchOverview, loadHistory } = {
    overview: useSecurityStore((s) => s.overview),
    fetchOverview: useSecurityStore((s) => s.fetchOverview),
    loadHistory: useScanStore((s) => s.loadHistory),
  };

  const initData = useCallback(async () => {
    await Promise.all([fetchOverview(), loadHistory()]);
  }, [fetchOverview, loadHistory]);

  useEffect(() => {
    initData();
  }, [initData]);

  return { overview, initData };
}
