// 主题 Hook
import { useColorScheme } from 'react-native';
import { useMemo } from 'react';
import { getColors, ThemeColors, ThemeMode } from '@theme/colors';
import { typography, Typography } from '@theme/typography';
import { spacing, radius, dimensions, Spacing, Radius, Dimensions } from '@theme/spacing';

export interface AppTheme {
  colors: ThemeColors;
  mode: ThemeMode;
  typography: Typography;
  spacing: Spacing;
  radius: Radius;
  dimensions: Dimensions;
}

/**
 * 获取当前主题
 * 自动跟随系统深色/浅色模式
 */
export function useTheme(): AppTheme {
  const colorScheme = useColorScheme();
  const mode: ThemeMode = colorScheme === 'dark' ? 'dark' : 'light';

  return useMemo(
    () => ({
      colors: getColors(mode),
      mode,
      typography,
      spacing,
      radius,
      dimensions,
    }),
    [mode]
  );
}
