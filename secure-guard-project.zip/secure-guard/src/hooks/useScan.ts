// 扫描 Hook - 封装扫描逻辑
import { useCallback } from 'react';
import { useScanStore } from '@store/scanStore';
import { ScanType } from '@types/scan';

export function useScan() {
  const {
    currentResult,
    isScanning,
    isPaused,
    currentProgress,
    currentItemName,
    history,
    startScan,
    pauseScan,
    resumeScan,
    cancelScan,
    resolveThreat,
    resolveAllThreats,
    ignoreThreat,
    loadHistory,
    clearResult,
  } = useScanStore();

  const handleStartScan = useCallback(
    async (type: ScanType = 'quick') => {
      return await startScan(type);
    },
    [startScan]
  );

  return {
    currentResult,
    isScanning,
    isPaused,
    currentProgress,
    currentItemName,
    history,
    startScan: handleStartScan,
    pauseScan,
    resumeScan,
    cancelScan,
    resolveThreat,
    resolveAllThreats,
    ignoreThreat,
    loadHistory,
    clearResult,
  };
}
