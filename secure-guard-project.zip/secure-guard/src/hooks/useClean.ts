// 清理 Hook
import { useCallback } from 'react';
import { useCleanStore } from '@store/cleanStore';

export function useClean() {
  const {
    junkFiles,
    categories,
    processes,
    memoryInfo,
    batteryInfo,
    lastCleanResult,
    loading,
    cleaning,
    loadJunkFiles,
    loadProcesses,
    loadMemoryInfo,
    loadBatteryInfo,
    loadAll,
    toggleJunkItem,
    toggleCategory,
    toggleProcess,
    selectAllJunk,
    cleanSelected,
    killSelectedProcesses,
    oneTapBoost,
    getSelectedJunkSize,
    getSelectedJunkCount,
  } = useCleanStore();

  const selectedJunkSize = getSelectedJunkSize();
  const selectedJunkCount = getSelectedJunkCount();

  const handleClean = useCallback(async () => {
    return await cleanSelected();
  }, [cleanSelected]);

  const handleBoost = useCallback(async () => {
    return await oneTapBoost();
  }, [oneTapBoost]);

  return {
    junkFiles,
    categories,
    processes,
    memoryInfo,
    batteryInfo,
    lastCleanResult,
    loading,
    cleaning,
    selectedJunkSize,
    selectedJunkCount,
    loadJunkFiles,
    loadProcesses,
    loadMemoryInfo,
    loadBatteryInfo,
    loadAll,
    toggleJunkItem,
    toggleCategory,
    toggleProcess,
    selectAllJunk,
    cleanSelected: handleClean,
    killSelectedProcesses,
    oneTapBoost: handleBoost,
  };
}
