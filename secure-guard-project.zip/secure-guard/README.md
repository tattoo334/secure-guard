# 安全卫士 - 手机杀毒软件

一款功能完整的移动端安全防护应用，基于 React Native + Expo + TypeScript 开发，支持 iOS 和 Android 双平台。

## 功能特性

### 核心安全功能
- **病毒扫描** - 支持快速扫描、全盘扫描、自定义扫描三种模式，基于特征码匹配检测病毒、木马、广告软件、间谍软件、勒索软件等威胁
- **实时防护** - 全天候监控应用安装和文件变化，实时检测安全威胁
- **病毒库更新** - 支持手动和自动更新病毒特征库，保持最新防护能力

### 设备优化
- **垃圾清理** - 智能分类清理应用缓存、安装包、临时文件、缩略图、卸载残留等
- **内存加速** - 一键关闭后台运行应用，释放内存提升设备性能
- **电池管理** - 查看电池状态和耗电应用排行

### 隐私保护
- **隐私检测** - 检测剪贴板读取、位置追踪、相册权限、麦克风使用等隐私风险
- **应用锁** - 为敏感应用添加图案/PIN/生物识别锁
- **隐私保险箱** - 加密存储敏感照片和文件
- **权限管理** - 查看和管理应用权限使用情况

### 骚扰拦截
- **电话拦截** - 智能识别骚扰、诈骗、广告推销电话
- **短信拦截** - 基于关键词和内容识别垃圾短信
- **拦截规则** - 支持号码、前缀、关键词、分类等多种拦截规则
- **拦截记录** - 完整的拦截历史记录和管理

### 应用管理
- **应用列表** - 查看所有已安装应用详情
- **风险检测** - 自动识别风险应用和过度授权应用
- **权限审计** - 查看应用申请的所有权限及风险等级
- **缓存清理** - 单独清理指定应用缓存

## 技术栈

| 类别 | 技术 |
|------|------|
| 框架 | React Native 0.74 |
| 开发工具 | Expo SDK 51 |
| 语言 | TypeScript 5.3 |
| 导航 | Expo Router 3.5 |
| 状态管理 | Zustand 4.5 |
| 网络请求 | Axios |
| 本地存储 | AsyncStorage |
| 图标 | @expo/vector-icons |
| 动画 | react-native-reanimated |
| SVG | react-native-svg |

## 项目结构

```
secure-guard/
├── app/                          # Expo Router 路由目录
│   ├── (tabs)/                   # 标签页分组
│   │   ├── _layout.tsx           # Tab 导航布局
│   │   ├── index.tsx             # 首页 - 安全概览
│   │   ├── scan.tsx              # 病毒扫描页
│   │   ├── clean.tsx             # 清理加速页
│   │   └── profile.tsx           # 个人中心
│   ├── _layout.tsx               # 根布局
│   ├── scan-result.tsx           # 扫描结果页
│   ├── app-manager.tsx           # 应用管理页
│   ├── app-detail.tsx            # 应用详情页
│   ├── privacy.tsx               # 隐私保护页
│   ├── intercept.tsx             # 骚扰拦截页
│   ├── settings.tsx              # 设置页
│   ├── virus-db.tsx              # 病毒库更新页
│   └── scan-history.tsx          # 扫描历史页
├── src/
│   ├── components/
│   │   ├── ui/                    # 基础 UI 组件
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── ProgressRing.tsx
│   │   │   ├── ScanAnimation.tsx
│   │   │   ├── SettingSwitch.tsx
│   │   │   └── EmptyState.tsx
│   │   └── features/              # 业务功能组件
│   │       ├── SecurityScoreCard.tsx
│   │       ├── ThreatCard.tsx
│   │       ├── FeatureGrid.tsx
│   │       └── ScanProgressBar.tsx
│   ├── hooks/                     # 自定义 Hooks
│   │   ├── useTheme.ts
│   │   ├── useScan.ts
│   │   ├── useClean.ts
│   │   └── useAppData.ts
│   ├── store/                     # 状态管理 (Zustand)
│   │   ├── securityStore.ts
│   │   ├── scanStore.ts
│   │   ├── cleanStore.ts
│   │   └── settingsStore.ts
│   ├── services/                  # 服务层
│   │   ├── scanService.ts         # 扫描引擎服务
│   │   ├── cleanService.ts        # 清理服务
│   │   ├── appService.ts          # 应用管理服务
│   │   ├── blockService.ts        # 骚扰拦截服务
│   │   ├── privacyService.ts      # 隐私保护服务
│   │   ├── securityService.ts     # 安全概览服务
│   │   └── mock/                  # Mock 数据
│   │       ├── apps.ts
│   │       ├── threats.ts
│   │       ├── junkFiles.ts
│   │       ├── block.ts
│   │       └── privacy.ts
│   ├── types/                     # TypeScript 类型定义
│   │   ├── security.ts
│   │   ├── scan.ts
│   │   ├── clean.ts
│   │   ├── app.ts
│   │   ├── block.ts
│   │   └── privacy.ts
│   ├── utils/                     # 工具函数
│   │   ├── format.ts
│   │   ├── storage.ts
│   │   ├── constants.ts
│   │   └── helpers.ts
│   └── theme/                     # 主题配置
│       ├── colors.ts
│       ├── typography.ts
│       ├── spacing.ts
│       └── index.ts
├── assets/                        # 静态资源
├── app.json                       # Expo 配置
├── tsconfig.json                  # TypeScript 配置
├── babel.config.js                # Babel 配置
├── package.json                   # 依赖配置
├── .env.example                   # 环境变量模板
└── README.md
```

## 快速开始

### 环境要求
- Node.js >= 18
- npm 或 yarn
- Expo CLI（可选，npx 可直接使用）
- iOS 开发需要 macOS + Xcode
- Android 开发需要 Android Studio

### 安装步骤

1. **安装依赖**
```bash
cd secure-guard
npm install
```

2. **配置环境变量**
```bash
cp .env.example .env
```

3. **启动开发服务器**
```bash
npm start
```

4. **运行应用**
   - 使用 Expo Go 应用扫描二维码（推荐）
   - 或按 `a` 键在 Android 模拟器运行
   - 或按 `i` 键在 iOS 模拟器运行
   - 或按 `w` 键在浏览器中运行

### 构建发布

**Android APK:**
```bash
npx expo build:android
```

**iOS IPA:**
```bash
npx expo build:ios
```

**OTA 更新:**
```bash
npx expo publish
```

## 已实现功能清单

### 页面 (12个)
- [x] 首页 - 安全评分、功能入口、实时防护状态
- [x] 病毒扫描 - 扫描动画、三种扫描模式、进度显示
- [x] 扫描结果 - 威胁列表、一键处理、统计概览
- [x] 清理加速 - 垃圾分类、内存状态、进程管理
- [x] 个人中心 - 用户信息、快捷开关、功能菜单
- [x] 应用管理 - 应用列表、搜索筛选、风险标记
- [x] 应用详情 - 权限审计、存储信息、卸载操作
- [x] 隐私保护 - 隐私检测、应用锁、保险箱
- [x] 骚扰拦截 - 拦截记录、规则管理、统计数据
- [x] 设置 - 扫描设置、拦截设置、外观设置
- [x] 病毒库更新 - 版本信息、更新日志、自动更新
- [x] 扫描历史 - 历史记录、结果状态

### 组件 (10个)
- [x] Button - 多风格按钮组件
- [x] Card - 卡片容器组件
- [x] ProgressRing - 环形进度条
- [x] ScanAnimation - 雷达扫描动画
- [x] SettingSwitch - 设置开关组件
- [x] EmptyState - 空状态组件
- [x] SecurityScoreCard - 安全评分卡片
- [x] ThreatCard - 威胁项卡片
- [x] FeatureGrid - 功能入口网格
- [x] ScanProgressBar - 扫描进度条

### 服务 (6个)
- [x] 扫描引擎服务 - 模拟特征码扫描流程
- [x] 清理服务 - 垃圾扫描和清理
- [x] 应用服务 - 应用信息和权限管理
- [x] 拦截服务 - 骚扰电话短信拦截
- [x] 隐私服务 - 隐私检测和应用锁
- [x] 安全服务 - 安全概览和系统漏洞

## 设计说明

### 设计风格
- 采用科技感蓝色为主色调，传达安全、可信赖的品牌形象
- 支持深色/浅色模式自动切换
- 卡片式布局，层次分明
- 丰富的微交互动画

### 数据说明
- 当前版本使用 Mock 数据模拟所有功能，可直接运行体验
- 服务层已封装好接口，接入真实后端 API 时只需修改 service 文件
- 扫描引擎模拟了特征码匹配流程，包含进度回调和威胁检测逻辑

### 权限说明
Android 平台需要以下权限：
- 读取通讯录 - 识别骚扰电话
- 读取通话记录/短信 - 骚扰拦截
- 读取外部存储 - 文件扫描和清理
- 前台服务 - 实时防护
- 开机自启动 - 防护服务持续运行

## 后续可扩展方向

1. **云查杀引擎** - 接入云端病毒分析，提升未知威胁检测率
2. **AI 行为分析** - 基于机器学习的异常行为检测
3. **VPN 安全通道** - 公共 WiFi 下的安全加密传输
4. **防盗功能** - 远程定位、锁定、擦除数据
5. **家长控制** - 应用使用时长限制、内容过滤
6. **密码管理器** - 安全存储和自动填充密码
7. **WiFi 安全检测** - 检测 WiFi 网络安全风险
8. **数据备份** - 联系人、短信等数据加密备份

## 许可证

MIT License

## 免责声明

本应用仅供学习和研究使用。真实环境中的病毒防护需要专业的杀毒引擎和病毒库支持，本项目不构成实际的安全防护产品。
